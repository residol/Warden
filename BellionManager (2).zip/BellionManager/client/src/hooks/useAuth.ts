import { useQuery, useQueryClient } from '@tanstack/react-query';
import axios from 'axios';
import { useEffect } from 'react';

// Interfaccia per i dati dell'utente
export interface User {
  id: number;
  username: string;
  email: string;
  role: 'admin' | 'moderator' | 'member' | 'supporter';
  discordId?: string | null;
  isVerified: boolean;
  profileImageUrl?: string | null;
  createdAt: string;
}

// Hook per gestire l'autenticazione
export function useAuth() {
  const queryClient = useQueryClient();

  // Configura axios per includere il token in tutte le richieste
  useEffect(() => {
    const token = localStorage.getItem('accessToken');
    if (token) {
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    }

    return () => {
      delete axios.defaults.headers.common['Authorization'];
    };
  }, []);

  // Ottieni i dati dell'utente dal server
  const { data: user, isLoading, error, refetch } = useQuery({
    queryKey: ['/api/auth/profile'],
    queryFn: async () => {
      try {
        const token = localStorage.getItem('accessToken');
        if (!token) return null;

        const { data } = await axios.get('/api/auth/profile', {
          headers: { Authorization: `Bearer ${token}` }
        });
        return data.user as User;
      } catch (error) {
        // Se il token è scaduto o non valido, prova a rinnovarlo con il refresh token
        if (axios.isAxiosError(error) && error.response?.status === 401) {
          const refreshToken = localStorage.getItem('refreshToken');
          if (refreshToken) {
            try {
              const { data } = await axios.post('/api/auth/refresh', { token: refreshToken });
              localStorage.setItem('accessToken', data.accessToken);
              // Riprova la richiesta originale con il nuovo token
              const { data: userData } = await axios.get('/api/auth/profile', {
                headers: { Authorization: `Bearer ${data.accessToken}` }
              });
              return userData.user as User;
            } catch (refreshError) {
              // Se il refresh token non è valido, logout
              logout();
              return null;
            }
          } else {
            // Se non c'è refresh token, logout
            logout();
            return null;
          }
        }
        throw error;
      }
    },
    retry: false,
    enabled: !!localStorage.getItem('accessToken')
  });

  // Funzione per effettuare il login
  const login = async (username: string, password: string) => {
    try {
      const { data } = await axios.post('/api/auth/login', { username, password });
      
      localStorage.setItem('accessToken', data.accessToken);
      localStorage.setItem('refreshToken', data.refreshToken);
      
      // Aggiorna la cache con i dati utente
      queryClient.setQueryData(['/api/auth/profile'], data.user);
      
      // Forza il refetch per aggiornare lo stato di autenticazione
      await refetch();
      
      return data.user;
    } catch (error) {
      throw error;
    }
  };

  // Funzione per effettuare la registrazione
  const register = async (userData: { username: string; email: string; password: string; inviteToken?: string }) => {
    try {
      // Determina quale endpoint usare in base alla presenza di un inviteToken
      const endpoint = userData.inviteToken 
        ? '/api/auth/register-with-invite'
        : '/api/auth/register';
      
      const { data } = await axios.post(endpoint, userData);
      
      localStorage.setItem('accessToken', data.accessToken);
      localStorage.setItem('refreshToken', data.refreshToken);
      
      // Aggiorna la cache con i dati utente
      queryClient.setQueryData(['/api/auth/profile'], data.user);
      
      // Forza il refetch per aggiornare lo stato di autenticazione
      await refetch();
      
      return data.user;
    } catch (error) {
      throw error;
    }
  };

  // Funzione per il logout
  const logout = () => {
    localStorage.removeItem('accessToken');
    localStorage.removeItem('refreshToken');
    
    // Invalida la cache dell'utente
    queryClient.removeQueries({ queryKey: ['/api/auth/profile'] });
    
    // Rimuovi l'header di autorizzazione
    delete axios.defaults.headers.common['Authorization'];
  };

  // Verifica se l'utente ha un ruolo specifico
  const hasRole = (roles: string[]) => {
    return !!user && roles.includes(user.role);
  };

  // Verifica se l'utente è un amministratore
  const isAdmin = () => {
    return !!user && user.role === 'admin';
  };

  // Verifica se l'utente è un moderatore (o superiore)
  const isModerator = () => {
    return !!user && (user.role === 'admin' || user.role === 'moderator');
  };

  return {
    user,
    isLoading,
    isAuthenticated: !!user,
    hasError: !!error,
    login,
    register,
    logout,
    hasRole,
    isAdmin,
    isModerator,
    refetch
  };
}