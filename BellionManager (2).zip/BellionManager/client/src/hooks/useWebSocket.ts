import { useState, useEffect, useRef, useCallback } from 'react';

interface UseWebSocketOptions {
  onMessage?: (data: any) => void;
  reconnectInterval?: number;
  maxReconnectAttempts?: number;
}

export function useWebSocket(options: UseWebSocketOptions = {}) {
  const [isConnected, setIsConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState<any>(null);
  const socketRef = useRef<WebSocket | null>(null);
  const reconnectAttemptsRef = useRef(0);
  const reconnectIntervalRef = useRef<number | null>(null);

  const { 
    onMessage,
    reconnectInterval = 5000,
    maxReconnectAttempts = 5
  } = options;

  // Funzione per connettersi al WebSocket
  const connect = useCallback(() => {
    // Crea URL WebSocket con il protocollo corretto
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    // Chiudi la connessione esistente se presente
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.close();
    }

    // Crea nuova connessione
    const socket = new WebSocket(wsUrl);
    socketRef.current = socket;

    socket.addEventListener('close', (event) => {
      if (!event.wasClean) {
        setTimeout(() => {
          connect(); // Attempt to reconnect
        }, 3000); // Wait 3 seconds before reconnecting
      }
    });

    // Gestione eventi WebSocket
    socket.onopen = () => {
      console.log('WebSocket connesso');
      setIsConnected(true);
      reconnectAttemptsRef.current = 0;

      if (reconnectIntervalRef.current) {
        clearInterval(reconnectIntervalRef.current);
        reconnectIntervalRef.current = null;
      }
    };

    socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        setLastMessage(data);
        if (onMessage) onMessage(data);
      } catch (error) {
        console.error('Errore nel parsing del messaggio WebSocket:', error);
      }
    };

    socket.onclose = () => {
      console.log('WebSocket disconnesso');
      setIsConnected(false);

      // Tenta di riconnettersi se non abbiamo raggiunto il numero massimo di tentativi
      if (reconnectAttemptsRef.current < maxReconnectAttempts) {
        reconnectIntervalRef.current = window.setTimeout(() => {
          reconnectAttemptsRef.current += 1;
          console.log(`Tentativo di riconnessione #${reconnectAttemptsRef.current}...`);
          connect();
        }, reconnectInterval);
      } else {
        console.log('Numero massimo di tentativi di riconnessione raggiunto');
      }
    };

    socket.onerror = (error) => {
      console.error('Errore WebSocket:', error);
    };
  }, [onMessage, reconnectInterval, maxReconnectAttempts]);

  // Invia un messaggio al server
  const sendMessage = useCallback((message: any) => {
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify(message));
      return true;
    }
    return false;
  }, []);

  // Disconnetti dal WebSocket
  const disconnect = useCallback(() => {
    if (socketRef.current) {
      socketRef.current.close();
      socketRef.current = null;
    }

    if (reconnectIntervalRef.current) {
      clearTimeout(reconnectIntervalRef.current);
      reconnectIntervalRef.current = null;
    }

    setIsConnected(false);
  }, []);

  // Connettiti al WebSocket quando il componente viene montato
  useEffect(() => {
    connect();

    // Pulizia alla smontaggio del componente
    return () => {
      disconnect();
    };
  }, [connect, disconnect]);

  return {
    isConnected,
    lastMessage,
    sendMessage,
    connect,
    disconnect
  };
}