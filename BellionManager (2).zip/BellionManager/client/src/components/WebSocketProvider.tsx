import { createContext, useContext, ReactNode } from 'react';
import { useWebSocket } from '../hooks/useWebSocket';
import { toast } from '@/hooks/use-toast';
import { useQueryClient } from '@tanstack/react-query';

// Crea un contesto per il WebSocket
interface WebSocketContextType {
  isConnected: boolean;
  sendMessage: (message: any) => boolean;
}

const WebSocketContext = createContext<WebSocketContextType | null>(null);

// Provider che gestisce la connessione WebSocket
export function WebSocketProvider({ children }: { children: ReactNode }) {
  const queryClient = useQueryClient();
  
  // Gestisci i messaggi ricevuti dal WebSocket
  const onMessage = (data: any) => {
    switch (data.type) {
      case 'servers':
        // Aggiorna la cache dei server
        queryClient.setQueryData(['/api/servers'], data.data);
        break;
      
      case 'alerts':
        // Aggiorna la cache degli avvisi
        queryClient.setQueryData(['/api/alerts'], data.data);
        
        // Mostra una notifica toast per ogni nuovo avviso
        if (Array.isArray(data.data) && data.data.length > 0) {
          const latestAlert = data.data[0];
          toast({
            title: 'Nuovo avviso di sistema',
            description: latestAlert.message,
            variant: latestAlert.level === 'critical' ? 'destructive' : 'default',
          });
        }
        break;
      
      case 'server_status_change':
        // Aggiorna la cache del server specifico
        queryClient.invalidateQueries({ queryKey: ['/api/servers', data.data.id] });
        
        // Mostra una notifica toast per il cambio di stato del server
        toast({
          title: 'Aggiornamento stato server',
          description: `Il server ${data.data.name} è ora ${data.data.status}`,
        });
        break;
      
      case 'wireguard_status':
        // Aggiorna lo stato WireGuard
        queryClient.invalidateQueries({ queryKey: ['/api/wireguard/status'] });
        
        if (data.data.peerConnected) {
          toast({
            title: 'Connessione WireGuard',
            description: `Un peer WireGuard si è connesso: ${data.data.peerName || 'Peer sconosciuto'}`,
          });
        }
        break;
    }
  };
  
  // Usa il hook WebSocket con la funzione di callback
  const { isConnected, sendMessage } = useWebSocket({ onMessage });
  
  return (
    <WebSocketContext.Provider value={{ isConnected, sendMessage }}>
      {children}
    </WebSocketContext.Provider>
  );
}

// Hook personalizzato per utilizzare il contesto WebSocket
export function useWebSocketContext() {
  const context = useContext(WebSocketContext);
  if (!context) {
    throw new Error('useWebSocketContext deve essere utilizzato all\'interno di un WebSocketProvider');
  }
  return context;
}