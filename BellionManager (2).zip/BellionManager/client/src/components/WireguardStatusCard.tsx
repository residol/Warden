import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Network, Activity, Shield, Wifi, WifiOff, ArrowRight, Users } from 'lucide-react';
import { Link } from 'wouter';

interface WireguardStatus {
  interface?: string;
  listenPort?: number;
  publicKey?: string;
  peers?: Array<{
    publicKey: string;
    allowedIps: string;
    latestHandshake: string;
    isOnline?: boolean;
    name?: string;
  }>;
  status?: 'online' | 'offline' | 'degraded';
  totalTraffic?: string;
  onlinePeers?: number;
  totalPeers?: number;
}

const WireguardStatusCard: React.FC = () => {
  const { data: wireguardStatus, isLoading, error } = useQuery<WireguardStatus>({
    queryKey: ['/api/wireguard/status'],
    refetchInterval: 30000, // Aggiorna ogni 30 secondi
  });

  if (isLoading) {
    return (
      <Card className="col-span-1 h-full">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg flex items-center gap-2">
            <Network size={18} />
            Rete WireGuard
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">Caricamento...</p>
        </CardContent>
      </Card>
    );
  }

  if (error || !wireguardStatus) {
    return (
      <Card className="col-span-1 h-full">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg flex items-center gap-2">
            <Network size={18} />
            Rete WireGuard
          </CardTitle>
          <CardDescription>Errore di connessione</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center h-24">
            <WifiOff className="text-red-500" size={24} />
            <p className="ml-2 text-sm text-red-500">
              Impossibile caricare i dati della rete
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const onlinePeers = wireguardStatus.onlinePeers || 0;
  const totalPeers = wireguardStatus.totalPeers || 0;
  const isNetworkOnline = wireguardStatus.status === 'online';

  return (
    <Card className="col-span-1 h-full">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg flex items-center gap-2">
            <Network size={18} />
            Rete WireGuard
          </CardTitle>
          <Badge variant={isNetworkOnline ? "success" : "destructive"}>
            {isNetworkOnline ? (
              <><Wifi className="mr-1" size={12} /> Online</>
            ) : (
              <><WifiOff className="mr-1" size={12} /> Offline</>
            )}
          </Badge>
        </div>
        <CardDescription>
          {wireguardStatus.interface} (porta: {wireguardStatus.listenPort})
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Statistiche principali */}
          <div className="grid grid-cols-2 gap-2">
            <div className="rounded-lg bg-slate-100 dark:bg-slate-800 p-3">
              <div className="flex items-center gap-2 text-sm">
                <Users size={16} className="text-blue-500" />
                <span>Client connessi</span>
              </div>
              <p className="text-2xl font-bold mt-1">
                {onlinePeers}/{totalPeers}
              </p>
            </div>
            <div className="rounded-lg bg-slate-100 dark:bg-slate-800 p-3">
              <div className="flex items-center gap-2 text-sm">
                <Activity size={16} className="text-green-500" />
                <span>Traffico totale</span>
              </div>
              <p className="text-2xl font-bold mt-1">
                {wireguardStatus.totalTraffic || '0 B'}
              </p>
            </div>
          </div>

          <Separator />

          {/* Regole firewall attive */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Shield size={16} className="text-amber-500" />
              <h3 className="font-medium">Protezione della rete</h3>
            </div>
            <p className="text-sm text-muted-foreground">
              Regole firewall attive per {totalPeers} dispositivi
            </p>
          </div>

          <Link href="/wireguard-network">
            <Button variant="outline" className="w-full" size="sm">
              Gestisci rete WireGuard
              <ArrowRight className="ml-2" size={16} />
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
};

export default WireguardStatusCard;