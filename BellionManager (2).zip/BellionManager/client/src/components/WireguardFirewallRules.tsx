import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { FirewallRule } from '@/lib/types';
import { 
  Shield, 
  Plus, 
  Trash2, 
  ArrowDownUp, 
  Ban, 
  Check, 
  Lock, 
  AlertTriangle
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription, 
  DialogFooter
} from '@/components/ui/dialog';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';

interface WireguardPeer {
  id: number;
  name: string;
  description?: string;
  publicKey: string;
  allowedIps: string;
}

const WireguardFirewallRules: React.FC = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Stato per il form della nuova regola
  const [isNewRuleOpen, setIsNewRuleOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [selectedRuleId, setSelectedRuleId] = useState<number | null>(null);
  
  const [newRule, setNewRule] = useState({
    peerId: 0,
    type: 'limit',
    direction: 'both',
    protocol: 'all',
    port: '',
    portRange: '',
    rateLimit: '',
    description: ''
  });

  // Ottieni i peer
  const { data: peers, isLoading: isLoadingPeers } = useQuery<WireguardPeer[]>({
    queryKey: ['/api/wireguard/peers'],
    refetchInterval: 60000,
  });

  // Ottieni le regole firewall
  const { data: rules, isLoading: isLoadingRules } = useQuery<FirewallRule[]>({
    queryKey: ['/api/wireguard/firewall'],
    refetchInterval: 60000,
  });

  // Mutazione per creare una nuova regola
  const createRuleMutation = useMutation({
    mutationFn: (data: any) => apiRequest('POST', '/api/wireguard/firewall', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/wireguard/firewall'] });
      toast({
        title: "Regola creata",
        description: "La regola firewall è stata creata con successo",
      });
      setIsNewRuleOpen(false);
      resetNewRule();
    },
    onError: (error) => {
      console.error('Errore nella creazione della regola:', error);
      toast({
        title: "Errore",
        description: "Impossibile creare la regola firewall",
        variant: "destructive",
      });
    }
  });

  // Mutazione per eliminare una regola
  const deleteRuleMutation = useMutation({
    mutationFn: (ruleId: number) => apiRequest('DELETE', `/api/wireguard/firewall/${ruleId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/wireguard/firewall'] });
      toast({
        title: "Regola eliminata",
        description: "La regola firewall è stata eliminata con successo",
      });
      setIsDeleteOpen(false);
    },
    onError: (error) => {
      console.error('Errore nell\'eliminazione della regola:', error);
      toast({
        title: "Errore",
        description: "Impossibile eliminare la regola firewall",
        variant: "destructive",
      });
    }
  });

  // Mutazione per abilitare/disabilitare una regola
  const toggleRuleMutation = useMutation({
    mutationFn: ({ ruleId, enabled }: { ruleId: number; enabled: boolean }) => 
      apiRequest('PATCH', `/api/wireguard/firewall/${ruleId}`, { enabled }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/wireguard/firewall'] });
      toast({
        title: "Regola aggiornata",
        description: "Lo stato della regola firewall è stato aggiornato",
      });
    },
    onError: (error) => {
      console.error('Errore nell\'aggiornamento della regola:', error);
      toast({
        title: "Errore",
        description: "Impossibile aggiornare la regola firewall",
        variant: "destructive",
      });
    }
  });

  const resetNewRule = () => {
    setNewRule({
      peerId: 0,
      type: 'limit',
      direction: 'both',
      protocol: 'all',
      port: '',
      portRange: '',
      rateLimit: '',
      description: ''
    });
  };

  const handleCreateRule = () => {
    // Validazione di base
    if (newRule.peerId === 0) {
      toast({
        title: "Errore",
        description: "Seleziona un dispositivo",
        variant: "destructive",
      });
      return;
    }

    if (newRule.type === 'limit' && !newRule.rateLimit) {
      toast({
        title: "Errore",
        description: "Inserisci un limite di velocità",
        variant: "destructive",
      });
      return;
    }

    const ruleData: any = {
      peerId: newRule.peerId,
      type: newRule.type,
      direction: newRule.direction,
      protocol: newRule.protocol,
      description: newRule.description || undefined
    };

    // Aggiungi i campi in base al tipo di regola
    if (newRule.type === 'limit') {
      ruleData.rateLimit = parseInt(newRule.rateLimit);
    } else if (['allow', 'block'].includes(newRule.type) && newRule.port) {
      ruleData.port = parseInt(newRule.port);
    } else if (['allow', 'block'].includes(newRule.type) && newRule.portRange) {
      ruleData.portRange = newRule.portRange;
    }

    createRuleMutation.mutate(ruleData);
  };

  // Funzione per ottenere il nome del peer
  const getPeerName = (peerId: number) => {
    if (!peers) return "Dispositivo sconosciuto";
    const peer = peers.find(p => p.id === peerId);
    return peer ? peer.name : "Dispositivo sconosciuto";
  };

  // Funzione per formattare il tipo di regola
  const formatRuleType = (type: string) => {
    switch (type) {
      case 'limit': return "Limitazione";
      case 'allow': return "Permesso";
      case 'block': return "Blocco";
      default: return type;
    }
  };

  // Funzione per formattare la direzione
  const formatDirection = (direction: string) => {
    switch (direction) {
      case 'in': return "Ingresso";
      case 'out': return "Uscita";
      case 'both': return "Entrambe";
      default: return direction;
    }
  };

  // Funzione per determinare l'icona del tipo di regola
  const getRuleTypeIcon = (type: string) => {
    switch (type) {
      case 'limit': return <ArrowDownUp className="h-4 w-4" />;
      case 'allow': return <Check className="h-4 w-4" />;
      case 'block': return <Ban className="h-4 w-4" />;
      default: return <Shield className="h-4 w-4" />;
    }
  };

  // Funzione per determinare il colore del badge
  const getRuleTypeBadgeVariant = (type: string) => {
    switch (type) {
      case 'limit': return "default";
      case 'allow': return "success";
      case 'block': return "destructive";
      default: return "outline";
    }
  };

  if (isLoadingPeers || isLoadingRules) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Regole Firewall</CardTitle>
          <CardDescription>Configurazione delle regole di accesso per i dispositivi VPN</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-center py-8">Caricamento regole...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div>
          <CardTitle>Regole Firewall</CardTitle>
          <CardDescription>Configura le regole di accesso per i tuoi dispositivi VPN</CardDescription>
        </div>
        <Button onClick={() => setIsNewRuleOpen(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Nuova regola
        </Button>
      </CardHeader>
      <CardContent>
        <div className="text-sm p-4 bg-amber-50 border border-amber-200 rounded-md mb-4">
          <AlertTriangle className="inline mr-2 text-amber-500" size={16} />
          Le regole vengono applicate nell'ordine in cui appaiono. Le regole di blocco hanno priorità sulle regole di permesso.
        </div>

        {(!rules || rules.length === 0) ? (
          <div className="text-center py-8">
            <Lock className="h-12 w-12 mx-auto text-gray-300 mb-4" />
            <p className="text-gray-500 mb-4">Nessuna regola firewall configurata</p>
            <Button variant="outline" onClick={() => setIsNewRuleOpen(true)}>
              Crea la prima regola
            </Button>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Dispositivo</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Direzione</TableHead>
                <TableHead>Dettagli</TableHead>
                <TableHead>Stato</TableHead>
                <TableHead className="text-right">Azioni</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rules.map((rule) => (
                <TableRow key={rule.id}>
                  <TableCell className="font-medium">{getPeerName(rule.peerId)}</TableCell>
                  <TableCell>
                    <Badge variant={getRuleTypeBadgeVariant(rule.type) as any} className="flex items-center gap-1 w-fit">
                      {getRuleTypeIcon(rule.type)}
                      {formatRuleType(rule.type)}
                    </Badge>
                  </TableCell>
                  <TableCell>{formatDirection(rule.direction)}</TableCell>
                  <TableCell>
                    {rule.type === 'limit' ? (
                      <span>Limite: {rule.rateLimit} Kbps</span>
                    ) : rule.port ? (
                      <span>Porta: {rule.port}</span>
                    ) : rule.portRange ? (
                      <span>Porte: {rule.portRange}</span>
                    ) : (
                      <span>Tutto il traffico</span>
                    )}
                    {rule.protocol && rule.protocol !== 'all' && (
                      <span className="ml-2 text-xs text-gray-500">[{rule.protocol.toUpperCase()}]</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <Switch
                      checked={rule.enabled}
                      onCheckedChange={(checked) => 
                        toggleRuleMutation.mutate({ ruleId: rule.id, enabled: checked })
                      }
                      aria-label={`Abilita/disabilita regola ${rule.id}`}
                    />
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => {
                        setSelectedRuleId(rule.id);
                        setIsDeleteOpen(true);
                      }}
                      className="text-red-500 hover:text-red-700 hover:bg-red-100"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>

      {/* Dialog per una nuova regola */}
      <Dialog open={isNewRuleOpen} onOpenChange={setIsNewRuleOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Nuova regola firewall</DialogTitle>
            <DialogDescription>
              Configura una nuova regola per gestire il traffico di rete dei dispositivi VPN.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="device">Dispositivo</Label>
              <Select 
                onValueChange={(value) => setNewRule({...newRule, peerId: parseInt(value)})}
                value={newRule.peerId.toString()}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Seleziona dispositivo" />
                </SelectTrigger>
                <SelectContent>
                  {peers?.map((peer) => (
                    <SelectItem key={peer.id} value={peer.id.toString()}>
                      {peer.name} ({peer.allowedIps.split('/')[0]})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="type">Tipo di regola</Label>
              <Select 
                onValueChange={(value) => setNewRule({...newRule, type: value})}
                value={newRule.type}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Seleziona tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="limit">Limitazione bandwidth</SelectItem>
                  <SelectItem value="allow">Permetti traffico</SelectItem>
                  <SelectItem value="block">Blocca traffico</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="direction">Direzione</Label>
              <Select 
                onValueChange={(value) => setNewRule({...newRule, direction: value})}
                value={newRule.direction}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Seleziona direzione" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="in">Solo ingresso</SelectItem>
                  <SelectItem value="out">Solo uscita</SelectItem>
                  <SelectItem value="both">Entrambe le direzioni</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="protocol">Protocollo</Label>
              <Select 
                onValueChange={(value) => setNewRule({...newRule, protocol: value})}
                value={newRule.protocol}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Seleziona protocollo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tutti i protocolli</SelectItem>
                  <SelectItem value="tcp">TCP</SelectItem>
                  <SelectItem value="udp">UDP</SelectItem>
                  <SelectItem value="icmp">ICMP</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {newRule.type === 'limit' && (
              <div className="space-y-2">
                <Label htmlFor="rateLimit">Limite di velocità (Kbps)</Label>
                <Input 
                  id="rateLimit" 
                  type="number" 
                  placeholder="es. 1000 per 1Mbps"
                  value={newRule.rateLimit}
                  onChange={(e) => setNewRule({...newRule, rateLimit: e.target.value})}
                />
              </div>
            )}
            
            {['allow', 'block'].includes(newRule.type) && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="port">Porta singola (opzionale)</Label>
                  <Input 
                    id="port" 
                    type="number" 
                    placeholder="es. 80"
                    value={newRule.port}
                    onChange={(e) => setNewRule({...newRule, port: e.target.value, portRange: ''})}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="portRange">Intervallo porte (opzionale)</Label>
                  <Input 
                    id="portRange" 
                    placeholder="es. 1000-2000"
                    value={newRule.portRange}
                    onChange={(e) => setNewRule({...newRule, portRange: e.target.value, port: ''})}
                  />
                  <p className="text-xs text-muted-foreground">Formato: inizio-fine (es. 1000-2000)</p>
                </div>
              </>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="description">Descrizione (opzionale)</Label>
              <Input 
                id="description" 
                placeholder="es. Limitazione per streaming video"
                value={newRule.description}
                onChange={(e) => setNewRule({...newRule, description: e.target.value})}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setIsNewRuleOpen(false);
              resetNewRule();
            }}>
              Annulla
            </Button>
            <Button 
              onClick={handleCreateRule}
              disabled={createRuleMutation.isPending}
            >
              {createRuleMutation.isPending ? "Creazione..." : "Crea regola"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Dialog per conferma eliminazione */}
      <Dialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Conferma eliminazione</DialogTitle>
            <DialogDescription>
              Sei sicuro di voler eliminare questa regola firewall?
              <br />
              Questa azione non può essere annullata.
            </DialogDescription>
          </DialogHeader>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteOpen(false)}>Annulla</Button>
            <Button 
              variant="destructive" 
              onClick={() => selectedRuleId && deleteRuleMutation.mutate(selectedRuleId)}
              disabled={deleteRuleMutation.isPending}
            >
              {deleteRuleMutation.isPending ? "Eliminazione..." : "Elimina regola"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
};

export default WireguardFirewallRules;