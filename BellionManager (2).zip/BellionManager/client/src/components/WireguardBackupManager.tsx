import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Archive, Trash2, RotateCcw, Calendar, Clock, HardDrive, Database } from 'lucide-react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";

interface BackupInfo {
  name: string;
  date: string;
  size: number;
  peerCount: number;
  error?: boolean;
}

const WireguardBackupManager: React.FC = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isConfirmDeleteOpen, setIsConfirmDeleteOpen] = useState(false);
  const [isConfirmRestoreOpen, setIsConfirmRestoreOpen] = useState(false);
  const [selectedBackup, setSelectedBackup] = useState<BackupInfo | null>(null);

  // Ottieni tutti i backup disponibili
  const { data: backups, isLoading, error } = useQuery<BackupInfo[]>({
    queryKey: ['/api/wireguard/backups'],
    refetchInterval: 60000, // Aggiorna ogni minuto
  });

  // Mutation per creare un nuovo backup
  const createBackupMutation = useMutation({
    mutationFn: () => apiRequest('POST', '/api/wireguard/backups'),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/wireguard/backups'] });
      
      toast({
        title: "Backup creato",
        description: "Il backup delle configurazioni WireGuard è stato creato con successo",
      });
    },
    onError: (error) => {
      console.error('Errore nella creazione del backup:', error);
      toast({
        title: "Errore",
        description: "Impossibile creare il backup delle configurazioni",
        variant: "destructive",
      });
    }
  });

  // Mutation per eliminare un backup
  const deleteBackupMutation = useMutation({
    mutationFn: (backupName: string) => 
      apiRequest('DELETE', `/api/wireguard/backups/${backupName}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/wireguard/backups'] });
      
      toast({
        title: "Backup eliminato",
        description: "Il backup delle configurazioni WireGuard è stato eliminato con successo",
      });
      
      setIsConfirmDeleteOpen(false);
      setSelectedBackup(null);
    },
    onError: (error) => {
      console.error('Errore nell\'eliminazione del backup:', error);
      toast({
        title: "Errore",
        description: "Impossibile eliminare il backup delle configurazioni",
        variant: "destructive",
      });
    }
  });

  // Mutation per ripristinare un backup
  const restoreBackupMutation = useMutation({
    mutationFn: (backupName: string) => 
      apiRequest('POST', `/api/wireguard/backups/${backupName}/restore`),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/wireguard/peers'] });
      queryClient.invalidateQueries({ queryKey: ['/api/wireguard/status'] });
      
      toast({
        title: "Backup ripristinato",
        description: `Ripristinate ${data.restoredCount} configurazioni`,
      });
      
      setIsConfirmRestoreOpen(false);
      setSelectedBackup(null);
    },
    onError: (error) => {
      console.error('Errore nel ripristino del backup:', error);
      toast({
        title: "Errore",
        description: "Impossibile ripristinare il backup",
        variant: "destructive",
      });
    }
  });

  // Funzioni per formattare i dati
  const formatBytes = (bytes: number): string => {
    if (bytes === 0) return '0 B';
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return `${parseFloat((bytes / Math.pow(1024, i)).toFixed(2))} ${sizes[i]}`;
  };

  const formatDate = (dateString: string): string => {
    return new Date(dateString).toLocaleString();
  };

  // Estrai il timestamp dal nome del backup
  const extractTimestampFromBackupName = (backupName: string): string => {
    const match = backupName.match(/backup_(.+)/);
    if (match && match[1]) {
      try {
        const dateString = match[1].replace(/-/g, ':');
        return formatDate(dateString);
      } catch (e) {
        return "Data sconosciuta";
      }
    }
    return "Data sconosciuta";
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Backup Configurazioni</CardTitle>
          <CardDescription>Gestisci i backup delle configurazioni WireGuard</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-center py-8">Caricamento backup...</p>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Backup Configurazioni</CardTitle>
          <CardDescription>Gestisci i backup delle configurazioni WireGuard</CardDescription>
        </CardHeader>
        <CardContent>
          <Alert variant="destructive">
            <AlertTitle>Errore</AlertTitle>
            <AlertDescription>Si è verificato un errore nel caricamento dei backup. Riprova più tardi.</AlertDescription>
          </Alert>
        </CardContent>
        <CardFooter>
          <Button variant="outline" onClick={() => queryClient.invalidateQueries({ queryKey: ['/api/wireguard/backups'] })}>
            Riprova
          </Button>
        </CardFooter>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div>
          <CardTitle>Backup Configurazioni</CardTitle>
          <CardDescription>Gestisci i backup delle configurazioni WireGuard</CardDescription>
        </div>
        <Button 
          onClick={() => createBackupMutation.mutate()}
          disabled={createBackupMutation.isPending}
        >
          <Archive className="mr-2 h-4 w-4" />
          {createBackupMutation.isPending ? "Creazione..." : "Crea backup"}
        </Button>
      </CardHeader>
      <CardContent>
        {(!backups || backups.length === 0) ? (
          <div className="text-center py-8">
            <Database className="h-12 w-12 mx-auto text-gray-300 mb-4" />
            <p className="text-gray-500 mb-4">Nessun backup disponibile</p>
            <Button variant="outline" onClick={() => createBackupMutation.mutate()}>
              Crea il primo backup
            </Button>
          </div>
        ) : (
          <ScrollArea className="h-[400px] rounded-md border p-4">
            <div className="space-y-4">
              {backups.map((backup) => (
                <div key={backup.name} className="flex flex-col space-y-2 border-b pb-4 last:border-0">
                  <div className="flex justify-between items-start">
                    <div className="space-y-1">
                      <div className="flex items-center">
                        <h3 className="font-semibold">{backup.name.replace(/^backup_/, '')}</h3>
                        {backup.error && (
                          <Badge variant="destructive" className="ml-2">Errore</Badge>
                        )}
                      </div>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Calendar className="h-3.5 w-3.5 mr-1" />
                        <span>{extractTimestampFromBackupName(backup.name)}</span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => {
                          setSelectedBackup(backup);
                          setIsConfirmRestoreOpen(true);
                        }}
                        disabled={backup.error || restoreBackupMutation.isPending}
                      >
                        <RotateCcw className="h-3.5 w-3.5 mr-1" />
                        Ripristina
                      </Button>
                      <Button 
                        size="sm" 
                        variant="destructive"
                        onClick={() => {
                          setSelectedBackup(backup);
                          setIsConfirmDeleteOpen(true);
                        }}
                        disabled={deleteBackupMutation.isPending}
                      >
                        <Trash2 className="h-3.5 w-3.5 mr-1" />
                        Elimina
                      </Button>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="flex items-center">
                      <HardDrive className="h-3.5 w-3.5 mr-1.5 text-muted-foreground" />
                      <span>{formatBytes(backup.size)}</span>
                    </div>
                    <div className="flex items-center">
                      <Database className="h-3.5 w-3.5 mr-1.5 text-muted-foreground" />
                      <span>{backup.peerCount} dispositivi</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
      </CardContent>
      
      {/* Dialog per conferma eliminazione */}
      <Dialog open={isConfirmDeleteOpen} onOpenChange={setIsConfirmDeleteOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Conferma eliminazione</DialogTitle>
            <DialogDescription>
              Sei sicuro di voler eliminare il backup <strong>{selectedBackup?.name}</strong>?
              <br />
              Questa azione non può essere annullata.
            </DialogDescription>
          </DialogHeader>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsConfirmDeleteOpen(false)}>Annulla</Button>
            <Button 
              variant="destructive" 
              onClick={() => selectedBackup && deleteBackupMutation.mutate(selectedBackup.name)}
              disabled={deleteBackupMutation.isPending}
            >
              {deleteBackupMutation.isPending ? "Eliminazione..." : "Elimina backup"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Dialog per conferma ripristino */}
      <Dialog open={isConfirmRestoreOpen} onOpenChange={setIsConfirmRestoreOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Conferma ripristino</DialogTitle>
            <DialogDescription>
              Sei sicuro di voler ripristinare il backup <strong>{selectedBackup?.name}</strong>?
              <br />
              Questa azione sovrascriverà le configurazioni esistenti con quelle nel backup.
            </DialogDescription>
          </DialogHeader>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsConfirmRestoreOpen(false)}>Annulla</Button>
            <Button 
              onClick={() => selectedBackup && restoreBackupMutation.mutate(selectedBackup.name)}
              disabled={restoreBackupMutation.isPending}
            >
              {restoreBackupMutation.isPending ? "Ripristino..." : "Ripristina backup"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
};

export default WireguardBackupManager;