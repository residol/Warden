import React, { useState } from 'react';
import { apiRequest } from '@/lib/queryClient';

interface WireGuardConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  onGenerate: (config: string) => void;
}

const WireGuardConfigModal: React.FC<WireGuardConfigModalProps> = ({ 
  isOpen, 
  onClose, 
  onGenerate 
}) => {
  const [username, setUsername] = useState('');
  const [device, setDevice] = useState('Windows');
  const [ip, setIp] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleGenerate = async () => {
    if (!username || !device || !ip) {
      setError('Tutti i campi sono obbligatori');
      return;
    }

    const ipNum = parseInt(ip, 10);
    if (isNaN(ipNum) || ipNum < 10 || ipNum > 250) {
      setError('L\'IP deve essere un numero tra 10 e 250');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await apiRequest('POST', '/api/wireguard/config', {
        username,
        device,
        ip
      });
      
      const data = await response.json();
      onGenerate(data.config);
      onClose();
    } catch (err) {
      console.error('Failed to generate WireGuard config:', err);
      setError('Errore durante la generazione della configurazione');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50">
      <div className="bg-discord-input rounded-md w-full max-w-lg overflow-hidden">
        <div className="bg-discord-dark px-4 py-3 flex items-center justify-between">
          <h2 className="font-semibold text-white">Genera Configurazione WireGuard</h2>
          <button className="text-discord-muted hover:text-white" onClick={onClose}>
            <i className="fas fa-times"></i>
          </button>
        </div>
        
        <div className="p-6 space-y-4">
          <p className="text-discord-muted text-sm mb-4">Compila i campi per generare una nuova configurazione WireGuard personalizzata.</p>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Nome Utente</label>
              <input 
                type="text" 
                className="w-full bg-discord-dark border border-gray-700 rounded px-3 py-2 text-white" 
                placeholder="Es. user1"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">Dispositivo</label>
              <select 
                className="w-full bg-discord-dark border border-gray-700 rounded px-3 py-2 text-white"
                value={device}
                onChange={(e) => setDevice(e.target.value)}
              >
                <option>Windows</option>
                <option>Linux</option>
                <option>macOS</option>
                <option>Android</option>
                <option>iOS</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">Indirizzo IP</label>
              <div className="flex">
                <span className="inline-flex items-center px-3 bg-discord-dark border border-r-0 border-gray-700 rounded-l-md text-gray-500">
                  10.99.0.
                </span>
                <input 
                  type="text" 
                  className="flex-1 bg-discord-dark border border-gray-700 rounded-r px-3 py-2 text-white" 
                  placeholder="15"
                  value={ip}
                  onChange={(e) => setIp(e.target.value)}
                />
              </div>
              <p className="text-xs text-discord-muted mt-1">Un numero libero tra 10 e 250.</p>
            </div>
            
            {error && (
              <div className="text-discord-red text-sm py-2 px-3 bg-discord-red bg-opacity-10 rounded">
                {error}
              </div>
            )}
            
            <div className="pt-2 flex space-x-3">
              <button 
                type="button" 
                className="bg-discord-dark hover:bg-opacity-80 text-white flex-1 py-2 rounded-md border border-gray-700" 
                onClick={onClose}
                disabled={loading}
              >
                Annulla
              </button>
              <button 
                type="button" 
                className="bg-discord-blurple hover:bg-opacity-80 text-white flex-1 py-2 rounded-md flex items-center justify-center"
                onClick={handleGenerate}
                disabled={loading}
              >
                {loading ? (
                  <i className="fas fa-spinner fa-spin mr-2"></i>
                ) : (
                  <i className="fas fa-file-export mr-2"></i>
                )}
                Genera Configurazione
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default WireGuardConfigModal;
