import React from 'react';
import { Link, useLocation } from 'wouter';
import { cn } from '@/lib/utils';
import {
  Home,
  Activity,
  Network,
  Server,
  Settings,
  Shield,
  Users,
  HelpCircle
} from 'lucide-react';

const SideNav: React.FC = () => {
  const [location] = useLocation();

  const navItems = [
    { id: 'home', name: 'Dashboard', path: '/', icon: <Home size={20} /> },
    { id: 'resources', name: 'Monitoraggio Risorse', path: '/resource-monitor', icon: <Activity size={20} /> },
    { id: 'wireguard', name: 'Rete WireGuard', path: '/wireguard-network', icon: <Network size={20} /> },
    { id: 'servers', name: 'Server', path: '/servers', icon: <Server size={20} /> },
    { id: 'users', name: 'Utenti', path: '/users', icon: <Users size={20} /> },
    { id: 'security', name: 'Sicurezza', path: '/security', icon: <Shield size={20} /> },
    { id: 'settings', name: 'Impostazioni', path: '/settings', icon: <Settings size={20} /> },
    { id: 'help', name: 'Aiuto', path: '/help', icon: <HelpCircle size={20} /> }
  ];

  return (
    <div className="h-screen w-64 bg-slate-900 text-white p-4 flex flex-col">
      <div className="mb-8 p-4">
        <h1 className="text-xl font-bold flex items-center gap-2">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="w-6 h-6 text-green-500"
          >
            <path d="M12 2L4 7l8 5 8-5-8-5z" />
            <path d="M4 12l8 5 8-5" />
            <path d="M4 17l8 5 8-5" />
          </svg>
          Bellion Garden
        </h1>
      </div>

      <nav className="flex-1">
        <ul className="space-y-2">
          {navItems.map((item) => {
            const isActive = location === item.path;
            return (
              <li key={item.id}>
                <Link href={item.path}>
                  <a
                    className={cn(
                      "flex items-center p-3 rounded-lg transition-colors",
                      isActive
                        ? "bg-slate-800 text-green-400"
                        : "text-slate-300 hover:bg-slate-800 hover:text-white"
                    )}
                  >
                    <span className="mr-3">{item.icon}</span>
                    <span>{item.name}</span>
                    {item.id === 'wireguard' && (
                      <span className="ml-auto px-2 py-0.5 text-xs font-medium rounded-full bg-green-500 text-white">
                        Nuovo
                      </span>
                    )}
                  </a>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="mt-auto pt-4 border-t border-slate-800">
        <div className="flex items-center space-x-3 p-2">
          <div className="w-8 h-8 rounded-full bg-green-600 flex items-center justify-center">
            <span className="font-semibold text-white">A</span>
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium">Admin</p>
            <p className="text-xs text-slate-400">Online</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SideNav;