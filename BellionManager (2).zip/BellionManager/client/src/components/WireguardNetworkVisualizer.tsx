import React, { useEffect, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { CircleOff, Activity, Wifi, WifiOff, Network, Clock, ArrowDown, ArrowUp } from 'lucide-react';

interface WireguardPeer {
  publicKey: string;
  allowedIps: string;
  latestHandshake: string;
  transferRx?: number;
  transferTx?: number;
  persistentKeepalive?: string;
  isOnline?: boolean;
  name?: string;
}

interface WireguardStatus {
  interface: string;
  listenPort: number;
  publicKey: string;
  peers: WireguardPeer[];
  status: 'online' | 'offline' | 'degraded';
  totalTraffic: string;
  onlinePeers: number;
  totalPeers: number;
}

// Funzione per formattare i byte in forma leggibile
const formatBytes = (bytes?: number): string => {
  if (!bytes || bytes === 0) return '0 B';
  
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  
  return parseFloat((bytes / Math.pow(1024, i)).toFixed(2)) + ' ' + sizes[i];
};

// Funzione per formattare la data dell'ultimo handshake
const formatHandshakeTime = (timestamp: string): string => {
  const date = new Date(timestamp);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMinutes = Math.floor(diffMs / 60000);
  
  if (diffMinutes < 1) return 'Adesso';
  if (diffMinutes < 60) return `${diffMinutes} min fa`;
  
  const diffHours = Math.floor(diffMinutes / 60);
  if (diffHours < 24) return `${diffHours} ore fa`;
  
  const diffDays = Math.floor(diffHours / 24);
  return `${diffDays} giorni fa`;
};

// Funzione per determinare il colore in base allo stato di connessione
const getStatusColor = (isOnline: boolean): string => {
  return isOnline ? 'bg-green-500' : 'bg-red-500';
};

const WireguardNetworkVisualizer: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  const { data: wireguardStatus, isLoading, error } = useQuery({
    queryKey: ['/api/wireguard/status'],
    refetchInterval: 30000, // Aggiorna ogni 30 secondi
  });
  
  // Funzione per disegnare la rete
  const drawNetwork = (status: WireguardStatus) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Imposta le dimensioni del canvas
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
    
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = Math.min(centerX, centerY) - 50;
    
    // Pulisci il canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Disegna il server centrale
    ctx.beginPath();
    ctx.arc(centerX, centerY, 40, 0, 2 * Math.PI);
    ctx.fillStyle = status.status === 'online' ? '#10b981' : '#ef4444';
    ctx.fill();
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 3;
    ctx.stroke();
    
    // Etichetta del server
    ctx.font = '16px sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('Server', centerX, centerY);
    
    // Disegna i peer attorno al server
    const peers = status.peers;
    const angleStep = (2 * Math.PI) / (peers.length || 1);
    
    peers.forEach((peer, index) => {
      const angle = index * angleStep;
      const x = centerX + radius * Math.cos(angle);
      const y = centerY + radius * Math.sin(angle);
      
      // Disegna la linea di connessione
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.lineTo(x, y);
      ctx.strokeStyle = peer.isOnline ? '#10b981' : '#94a3b8';
      ctx.lineWidth = peer.isOnline ? 3 : 1;
      ctx.stroke();
      
      // Disegna il nodo del peer
      ctx.beginPath();
      ctx.arc(x, y, 30, 0, 2 * Math.PI);
      ctx.fillStyle = peer.isOnline ? '#10b981' : '#94a3b8';
      ctx.fill();
      ctx.strokeStyle = '#1e293b';
      ctx.lineWidth = 2;
      ctx.stroke();
      
      // Nome del peer
      ctx.font = '14px sans-serif';
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(peer.name || peer.allowedIps.split('/')[0], x, y);
      
      // Mostra attività di traffico se online
      if (peer.isOnline && (peer.transferRx || peer.transferTx)) {
        // Freccia traffico in entrata
        if (peer.transferRx && peer.transferRx > 0) {
          const arrowStart = {
            x: x - (x - centerX) * 0.2,
            y: y - (y - centerY) * 0.2
          };
          const arrowEnd = {
            x: centerX + (x - centerX) * 0.2,
            y: centerY + (y - centerY) * 0.2
          };
          
          drawArrow(ctx, arrowStart.x, arrowStart.y, arrowEnd.x, arrowEnd.y, '#3b82f6');
        }
        
        // Freccia traffico in uscita
        if (peer.transferTx && peer.transferTx > 0) {
          const arrowStart = {
            x: centerX + (x - centerX) * 0.2,
            y: centerY + (y - centerY) * 0.2
          };
          const arrowEnd = {
            x: x - (x - centerX) * 0.2,
            y: y - (y - centerY) * 0.2
          };
          
          drawArrow(ctx, arrowStart.x, arrowStart.y, arrowEnd.x, arrowEnd.y, '#ec4899');
        }
      }
    });
  };
  
  // Funzione per disegnare una freccia
  const drawArrow = (
    ctx: CanvasRenderingContext2D, 
    fromX: number, 
    fromY: number, 
    toX: number, 
    toY: number, 
    color: string
  ) => {
    const headlen = 10;
    const angle = Math.atan2(toY - fromY, toX - fromX);
    
    ctx.beginPath();
    ctx.moveTo(fromX, fromY);
    ctx.lineTo(toX, toY);
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.stroke();
    
    // Disegna la punta della freccia
    ctx.beginPath();
    ctx.moveTo(toX, toY);
    ctx.lineTo(
      toX - headlen * Math.cos(angle - Math.PI / 6),
      toY - headlen * Math.sin(angle - Math.PI / 6)
    );
    ctx.lineTo(
      toX - headlen * Math.cos(angle + Math.PI / 6),
      toY - headlen * Math.sin(angle + Math.PI / 6)
    );
    ctx.closePath();
    ctx.fillStyle = color;
    ctx.fill();
  };
  
  // Disegna la rete quando lo stato è caricato o aggiornato
  useEffect(() => {
    if (wireguardStatus) {
      drawNetwork(wireguardStatus);
    }
  }, [wireguardStatus]);
  
  // Ridisegna quando la finestra viene ridimensionata
  useEffect(() => {
    const handleResize = () => {
      if (wireguardStatus) {
        drawNetwork(wireguardStatus);
      }
    };
    
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [wireguardStatus]);
  
  if (isLoading) {
    return (
      <Card className="w-full h-96">
        <CardHeader>
          <CardTitle>Rete WireGuard</CardTitle>
          <CardDescription>Caricamento in corso...</CardDescription>
        </CardHeader>
      </Card>
    );
  }
  
  if (error || !wireguardStatus) {
    return (
      <Card className="w-full h-96">
        <CardHeader>
          <CardTitle>Rete WireGuard</CardTitle>
          <CardDescription>
            <CircleOff className="inline-block mr-2 text-red-500" size={20} />
            Errore nel caricamento dello stato WireGuard
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }
  
  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Rete WireGuard</CardTitle>
            <CardDescription>
              <Network className="inline-block mr-1" size={16} />
              Interfaccia: {wireguardStatus.interface} (porta: {wireguardStatus.listenPort})
            </CardDescription>
          </div>
          <Badge variant={wireguardStatus.status === 'online' ? 'success' : 'destructive'}>
            {wireguardStatus.status === 'online' ? (
              <><Wifi className="mr-1" size={14} /> Online</>
            ) : (
              <><WifiOff className="mr-1" size={14} /> Offline</>
            )}
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="flex flex-wrap gap-4 mb-4">
          <div className="flex items-center">
            <Activity className="mr-2 text-blue-500" size={20} />
            <span>Peer Attivi: <strong>{wireguardStatus.onlinePeers}</strong>/{wireguardStatus.totalPeers}</span>
          </div>
          <div className="flex items-center">
            <ArrowDown className="mr-2 text-green-500" size={20} />
            <ArrowUp className="mr-2 text-red-500" size={20} />
            <span>Traffico Totale: <strong>{wireguardStatus.totalTraffic}</strong></span>
          </div>
        </div>
        
        <div className="border rounded-lg p-2 bg-slate-50 dark:bg-slate-900 mb-4">
          <canvas ref={canvasRef} className="w-full h-[400px]"></canvas>
        </div>
        
        <h3 className="text-lg font-semibold mb-2">Dettagli dei Peer</h3>
        <Separator className="my-2" />
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
          {wireguardStatus.peers.map((peer, index) => (
            <div key={index} className="border rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <div className={`w-3 h-3 rounded-full ${getStatusColor(!!peer.isOnline)}`} />
                <h4 className="font-semibold">{peer.name || peer.allowedIps.split('/')[0]}</h4>
              </div>
              
              <div className="text-sm space-y-1 text-slate-700 dark:text-slate-300">
                <div className="flex items-start gap-2">
                  <span className="text-slate-500 min-w-[120px]">IP:</span>
                  <span>{peer.allowedIps}</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-slate-500 min-w-[120px]">Chiave:</span>
                  <span>{peer.publicKey.substring(0, 12)}...</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-slate-500 min-w-[120px]">
                    <Clock size={14} className="inline mr-1" /> Ultimo handshake:
                  </span>
                  <span>{formatHandshakeTime(peer.latestHandshake)}</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-slate-500 min-w-[120px]">
                    <ArrowDown size={14} className="inline mr-1 text-green-500" /> Download:
                  </span>
                  <span>{formatBytes(peer.transferRx)}</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-slate-500 min-w-[120px]">
                    <ArrowUp size={14} className="inline mr-1 text-red-500" /> Upload:
                  </span>
                  <span>{formatBytes(peer.transferTx)}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default WireguardNetworkVisualizer;