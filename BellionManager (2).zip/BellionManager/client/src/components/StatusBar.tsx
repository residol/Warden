import React from 'react';

interface StatusBarProps {
  wireguardStatus: 'online' | 'offline' | 'degraded';
  pterodactylStatus: 'connected' | 'disconnected';
  serverIp: string;
  usersConnected?: number;
}

const StatusBar: React.FC<StatusBarProps> = ({
  wireguardStatus,
  pterodactylStatus,
  serverIp,
  usersConnected
}) => {
  return (
    <div className="h-10 px-4 bg-discord-dark border-t border-gray-800 flex items-center justify-between text-xs">
      <div className="flex items-center space-x-4">
        <div className={`flex items-center ${wireguardStatus === 'online' ? 'text-discord-green' : 'text-discord-red'}`}>
          <i className="fas fa-circle text-xs mr-1"></i>
          <span>WireGuard: {wireguardStatus === 'online' ? 'Online' : 'Offline'}</span>
        </div>
        <div className={`flex items-center ${pterodactylStatus === 'connected' ? 'text-discord-green' : 'text-discord-red'}`}>
          <i className="fas fa-server text-xs mr-1"></i>
          <span>Pterodactyl: {pterodactylStatus === 'connected' ? 'Connected' : 'Disconnected'}</span>
        </div>
      </div>
      <div className="text-discord-muted">
        <span>Server IP: {serverIp}</span>
        <span className="mx-2">|</span>
        <span>{usersConnected} {usersConnected === 1 ? 'utente connesso' : 'utenti connessi'}</span>
      </div>
    </div>
  );
}

export default StatusBar;
