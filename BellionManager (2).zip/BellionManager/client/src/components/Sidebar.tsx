import { useState } from "react";
import { cn } from "@/lib/utils";

type SidebarCategory = {
  name: string;
  icon: string;
  channels: {
    id: string;
    name: string;
    type: "text" | "voice";
    active?: boolean;
    users?: number;
  }[];
};

interface SidebarProps {
  categories: SidebarCategory[];
  onChannelSelect: (categoryName: string, channelName: string) => void;
  selectedChannel: { category: string; channel: string } | null;
}

export function Sidebar({ categories, onChannelSelect, selectedChannel }: SidebarProps) {
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>(
    categories.reduce((acc, category) => {
      acc[category.name] = true;
      return acc;
    }, {} as Record<string, boolean>)
  );

  const toggleCategory = (categoryName: string) => {
    setExpandedCategories(prev => ({
      ...prev,
      [categoryName]: !prev[categoryName]
    }));
  };

  return (
    <div className="w-60 bg-discord-sidebar flex-shrink-0 h-full overflow-y-auto border-r border-gray-800">
      {/* Server Header */}
      <div className="p-4 border-b border-gray-800">
        <h1 className="text-xl font-semibold flex items-center">
          <i className="fas fa-leaf text-discord-green mr-2"></i>
          Bellion Garden
        </h1>
      </div>
      
      {/* Channel Categories */}
      <div className="p-2 text-discord-muted">
        {categories.map((category) => (
          <div className="mb-4" key={category.name}>
            <div 
              className="flex items-center justify-between mb-1 px-2 cursor-pointer group"
              onClick={() => toggleCategory(category.name)}
            >
              <span className="text-xs font-semibold uppercase tracking-wider group-hover:text-white">
                <i className={`fas fa-chevron-${expandedCategories[category.name] ? 'down' : 'right'} mr-1 text-xs`}></i>
                {category.name}
              </span>
              <i className="fas fa-plus text-xs opacity-0 group-hover:opacity-100"></i>
            </div>
            
            {/* Channels under category */}
            {expandedCategories[category.name] && (
              <div className="space-y-1">
                {category.channels.map((channel) => (
                  <div 
                    key={channel.id}
                    className={cn(
                      "flex items-center px-2 py-1 rounded hover:bg-discord-input cursor-pointer",
                      selectedChannel?.category === category.name && selectedChannel?.channel === channel.name
                        ? "bg-discord-input text-white"
                        : "text-discord-muted"
                    )}
                    onClick={() => onChannelSelect(category.name, channel.name)}
                  >
                    <i className={`fas fa-${channel.type === 'text' ? 'hashtag' : 'volume-up'} mr-2 text-discord-muted text-sm`}></i>
                    <span>{channel.name}</span>
                    {channel.users !== undefined && channel.users > 0 && (
                      <div className="ml-auto flex items-center space-x-1">
                        <span className="w-2 h-2 rounded-full bg-discord-green"></span>
                        <span className="text-xs">{channel.users}</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

export default Sidebar;
