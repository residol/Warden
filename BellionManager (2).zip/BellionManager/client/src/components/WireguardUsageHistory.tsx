import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Area, AreaChart } from 'recharts';
import { Calendar, Clock, ArrowDownToLine, ArrowUpFromLine, Activity, HardDrive, BarChart3, History } from 'lucide-react';

// Tipi per i dati del grafico
interface UsageDataPoint {
  timestamp: string;
  download: number;
  upload: number;
  total: number;
  activePeers: number;
}

interface PeerUsageData {
  peerId: number;
  peerName: string;
  data: UsageDataPoint[];
}

// Componente principale
const WireguardUsageHistory: React.FC = () => {
  const [timeRange, setTimeRange] = useState<string>('7d');
  const [chartType, setChartType] = useState<string>('traffic');
  const [selectedPeer, setSelectedPeer] = useState<string>('all');

  // Query per recuperare i dati di traffico storico dei peer WireGuard
  const { data: peerUsageData, isLoading, error } = useQuery<PeerUsageData[]>({
    queryKey: ['/api/wireguard/usage-history', timeRange],
    // Simuliamo dati di esempio per la visualizzazione
    queryFn: async () => {
      // In produzione, questa sarà una chiamata API reale
      // return await fetch(`/api/wireguard/usage-history?range=${timeRange}`).then(res => res.json());
      
      // Dati simulati per la demo
      return generateMockUsageData(timeRange);
    },
    refetchInterval: 60000 // Aggiorna ogni minuto
  });

  // Funzione per formattare i byte in una unità leggibile
  const formatBytes = (bytes: number, decimals = 2) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  };
  
  // Formatta l'etichetta del tempo in base al range selezionato
  const formatTimeLabel = (timestamp: string) => {
    const date = new Date(timestamp);
    
    switch(timeRange) {
      case '24h':
        return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      case '7d':
        return date.toLocaleDateString([], { weekday: 'short' });
      case '30d':
        return `${date.getDate()}/${date.getMonth() + 1}`;
      default:
        return date.toLocaleString();
    }
  };

  // Calcolo statistiche di riepilogo
  const calculateSummaryStats = () => {
    if (!peerUsageData || peerUsageData.length === 0) {
      return { totalDownload: 0, totalUpload: 0, peakUsage: 0, avgActivePeers: 0 };
    }
    
    let totalDownload = 0;
    let totalUpload = 0;
    let peakUsage = 0;
    let totalActivePeers = 0;
    let dataPointCount = 0;
    
    // Filtra i dati in base al peer selezionato
    if (selectedPeer === 'all') {
      peerUsageData.forEach(peer => {
        peer.data.forEach(point => {
          totalDownload += point.download;
          totalUpload += point.upload;
          peakUsage = Math.max(peakUsage, point.download + point.upload);
          totalActivePeers += point.activePeers;
          dataPointCount++;
        });
      });
    } else {
      const peer = peerUsageData.find(p => p.peerId.toString() === selectedPeer);
      if (peer) {
        peer.data.forEach(point => {
          totalDownload += point.download;
          totalUpload += point.upload;
          peakUsage = Math.max(peakUsage, point.download + point.upload);
          dataPointCount++;
        });
      }
    }
    
    const avgActivePeers = dataPointCount > 0 ? totalActivePeers / dataPointCount : 0;
    
    return {
      totalDownload,
      totalUpload,
      peakUsage,
      avgActivePeers: Math.round(avgActivePeers * 10) / 10
    };
  };
  
  // Prepara i dati per il grafico
  const prepareChartData = () => {
    if (!peerUsageData || peerUsageData.length === 0) return [];
    
    if (selectedPeer === 'all') {
      // Aggregazione dei dati per timestamp
      const aggregatedData: Record<string, UsageDataPoint> = {};
      
      peerUsageData.forEach(peer => {
        peer.data.forEach(point => {
          if (!aggregatedData[point.timestamp]) {
            aggregatedData[point.timestamp] = {
              timestamp: point.timestamp,
              download: 0,
              upload: 0,
              total: 0,
              activePeers: 0
            };
          }
          
          aggregatedData[point.timestamp].download += point.download;
          aggregatedData[point.timestamp].upload += point.upload;
          aggregatedData[point.timestamp].total += point.total;
          aggregatedData[point.timestamp].activePeers = Math.max(
            aggregatedData[point.timestamp].activePeers,
            point.activePeers
          );
        });
      });
      
      // Converti l'oggetto back in array e ordina per timestamp
      return Object.values(aggregatedData).sort((a, b) => 
        new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
      );
    } else {
      // Dati di un singolo peer
      const peer = peerUsageData.find(p => p.peerId.toString() === selectedPeer);
      return peer ? [...peer.data].sort((a, b) => 
        new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
      ) : [];
    }
  };
  
  const chartData = prepareChartData();
  const summaryStats = calculateSummaryStats();

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-xl flex items-center">
              <BarChart3 className="h-5 w-5 mr-2" />
              Storico Utilizzo WireGuard
            </CardTitle>
            <CardDescription>
              Monitoraggio del traffico e utilizzo della rete nel tempo
            </CardDescription>
          </div>
          <div className="flex gap-2">
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-24">
                <SelectValue placeholder="Periodo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="24h">24 ore</SelectItem>
                <SelectItem value="7d">7 giorni</SelectItem>
                <SelectItem value="30d">30 giorni</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={selectedPeer} onValueChange={setSelectedPeer}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Dispositivo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tutti</SelectItem>
                {peerUsageData?.map(peer => (
                  <SelectItem key={peer.peerId} value={peer.peerId.toString()}>
                    {peer.peerName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        {isLoading ? (
          <div className="h-80 flex items-center justify-center">
            <div className="flex flex-col items-center">
              <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mb-3"></div>
              <p className="text-muted-foreground">Caricamento dati...</p>
            </div>
          </div>
        ) : error ? (
          <Alert variant="destructive" className="mb-4">
            <AlertTitle>Errore</AlertTitle>
            <AlertDescription>
              Impossibile caricare i dati di utilizzo. Riprova più tardi.
            </AlertDescription>
          </Alert>
        ) : (
          <>
            {/* Riepilogo statistiche */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-card border rounded-lg p-4 flex flex-col">
                <span className="text-xs text-muted-foreground mb-1 flex items-center">
                  <ArrowDownToLine className="h-3.5 w-3.5 mr-1 text-green-500" /> Download Totale
                </span>
                <span className="text-xl font-semibold">{formatBytes(summaryStats.totalDownload)}</span>
              </div>
              
              <div className="bg-card border rounded-lg p-4 flex flex-col">
                <span className="text-xs text-muted-foreground mb-1 flex items-center">
                  <ArrowUpFromLine className="h-3.5 w-3.5 mr-1 text-blue-500" /> Upload Totale
                </span>
                <span className="text-xl font-semibold">{formatBytes(summaryStats.totalUpload)}</span>
              </div>
              
              <div className="bg-card border rounded-lg p-4 flex flex-col">
                <span className="text-xs text-muted-foreground mb-1 flex items-center">
                  <Activity className="h-3.5 w-3.5 mr-1 text-yellow-500" /> Picco Utilizzo
                </span>
                <span className="text-xl font-semibold">{formatBytes(summaryStats.peakUsage)}</span>
              </div>
              
              <div className="bg-card border rounded-lg p-4 flex flex-col">
                <span className="text-xs text-muted-foreground mb-1 flex items-center">
                  <HardDrive className="h-3.5 w-3.5 mr-1 text-purple-500" /> Media Dispositivi Attivi
                </span>
                <span className="text-xl font-semibold">{summaryStats.avgActivePeers}</span>
              </div>
            </div>
            
            {/* Grafici */}
            <Tabs defaultValue="traffic" value={chartType} onValueChange={setChartType}>
              <TabsList className="mb-4">
                <TabsTrigger value="traffic">Traffico</TabsTrigger>
                <TabsTrigger value="peers">Dispositivi Attivi</TabsTrigger>
              </TabsList>
              
              <TabsContent value="traffic" className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorDownload" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10B981" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="colorUpload" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#3B82F6" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                    <XAxis 
                      dataKey="timestamp" 
                      tickFormatter={formatTimeLabel}
                      stroke="#666"
                      tick={{ fill: '#888' }}
                    />
                    <YAxis 
                      tickFormatter={(value) => formatBytes(value, 0)}
                      stroke="#666"
                      tick={{ fill: '#888' }}
                    />
                    <Tooltip 
                      formatter={(value: number) => [formatBytes(value), '']}
                      labelFormatter={(label) => new Date(label).toLocaleString()}
                      contentStyle={{ backgroundColor: '#1e1e1e', border: '1px solid #333' }}
                      itemStyle={{ color: '#eee' }}
                      labelStyle={{ color: '#ccc' }}
                    />
                    <Legend />
                    <Area 
                      type="monotone" 
                      dataKey="download" 
                      name="Download" 
                      stroke="#10B981" 
                      fillOpacity={1}
                      fill="url(#colorDownload)"
                      activeDot={{ r: 8 }}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="upload" 
                      name="Upload" 
                      stroke="#3B82F6" 
                      fillOpacity={1}
                      fill="url(#colorUpload)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </TabsContent>
              
              <TabsContent value="peers" className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                    <XAxis 
                      dataKey="timestamp" 
                      tickFormatter={formatTimeLabel}
                      stroke="#666"
                      tick={{ fill: '#888' }}
                    />
                    <YAxis 
                      stroke="#666"
                      tick={{ fill: '#888' }}
                      domain={[0, 'dataMax + 1']}
                      allowDecimals={false}
                    />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#1e1e1e', border: '1px solid #333' }}
                      itemStyle={{ color: '#eee' }}
                      labelStyle={{ color: '#ccc' }}
                      formatter={(value: number) => [`${value} dispositivi`, '']}
                      labelFormatter={(label) => new Date(label).toLocaleString()}
                    />
                    <Legend />
                    <Line 
                      type="stepAfter" 
                      dataKey="activePeers" 
                      name="Dispositivi Attivi" 
                      stroke="#A855F7" 
                      strokeWidth={2}
                      dot={{ fill: '#A855F7', r: 4 }}
                      activeDot={{ r: 6 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </TabsContent>
            </Tabs>
            
            <div className="flex justify-end mt-6">
              <Button
                variant="outline"
                size="sm"
                className="text-xs flex items-center"
                onClick={() => window.location.href = '/wireguard-usage-details'}
              >
                <History className="h-3.5 w-3.5 mr-1.5" />
                Visualizza Report Completo
              </Button>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
};

// Funzione per generare dati di esempio per la demo
function generateMockUsageData(timeRange: string): PeerUsageData[] {
  const now = new Date();
  const dataPoints: UsageDataPoint[] = [];
  let interval: number;
  let count: number;
  
  // Configura l'intervallo di tempo e il numero di punti
  switch(timeRange) {
    case '24h':
      interval = 60 * 60 * 1000; // 1 ora
      count = 24;
      break;
    case '7d':
      interval = 24 * 60 * 60 * 1000; // 1 giorno
      count = 7;
      break;
    case '30d':
      interval = 24 * 60 * 60 * 1000; // 1 giorno
      count = 30;
      break;
    default:
      interval = 24 * 60 * 60 * 1000;
      count = 7;
  }
  
  // Genera punti dati con valori casuali ma realistici
  for (let i = 0; i < count; i++) {
    const timestamp = new Date(now.getTime() - (count - i - 1) * interval);
    
    // Genera traffico più pesante durante il giorno e più leggero di notte
    const hourOfDay = timestamp.getHours();
    const isActivePeriod = hourOfDay >= 9 && hourOfDay <= 23;
    
    // Download e upload base con variazione casuale
    const baseDownload = isActivePeriod ? 100 * 1024 * 1024 : 20 * 1024 * 1024; // 100 MB o 20 MB
    const baseUpload = isActivePeriod ? 30 * 1024 * 1024 : 5 * 1024 * 1024; // 30 MB o 5 MB
    
    // Aggiungi variazione casuale (±50%)
    const download = Math.round(baseDownload * (0.5 + Math.random()));
    const upload = Math.round(baseUpload * (0.5 + Math.random()));
    
    // Stima il numero di peer attivi
    const activePeers = isActivePeriod ? Math.floor(2 + Math.random() * 3) : Math.floor(Math.random() * 2);
    
    dataPoints.push({
      timestamp: timestamp.toISOString(),
      download,
      upload,
      total: download + upload,
      activePeers
    });
  }
  
  // Crea alcuni peer fittizi
  return [
    {
      peerId: 1,
      peerName: "Smartphone",
      data: dataPoints.map(p => ({
        ...p,
        download: Math.round(p.download * 0.3),
        upload: Math.round(p.upload * 0.2),
        total: Math.round(p.download * 0.3) + Math.round(p.upload * 0.2)
      }))
    },
    {
      peerId: 2,
      peerName: "Laptop",
      data: dataPoints.map(p => ({
        ...p,
        download: Math.round(p.download * 0.5),
        upload: Math.round(p.upload * 0.6),
        total: Math.round(p.download * 0.5) + Math.round(p.upload * 0.6)
      }))
    },
    {
      peerId: 3,
      peerName: "Tablet",
      data: dataPoints.map(p => ({
        ...p,
        download: Math.round(p.download * 0.2),
        upload: Math.round(p.upload * 0.2),
        total: Math.round(p.download * 0.2) + Math.round(p.upload * 0.2)
      }))
    }
  ];
}

export default WireguardUsageHistory;