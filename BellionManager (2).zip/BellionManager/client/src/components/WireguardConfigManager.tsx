import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Download, RefreshCw, Trash2, Shield, Plus } from 'lucide-react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from "@/components/ui/separator";

interface WireguardPeer {
  id: number;
  name: string;
  description?: string;
  publicKey: string;
  allowedIps: string;
  createdAt: string;
  lastHandshake?: string;
  transferRx?: number;
  transferTx?: number;
  isOnline?: boolean;
  enabled: boolean;
}

const WireguardConfigManager: React.FC = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [newPeerName, setNewPeerName] = useState('');
  const [newPeerDesc, setNewPeerDesc] = useState('');
  const [isNewConfigOpen, setIsNewConfigOpen] = useState(false);
  const [selectedPeer, setSelectedPeer] = useState<WireguardPeer | null>(null);
  const [isConfirmDeleteOpen, setIsConfirmDeleteOpen] = useState(false);

  // Ottieni tutti i peer WireGuard
  const { data: peers, isLoading } = useQuery<WireguardPeer[]>({
    queryKey: ['/api/wireguard/peers'],
    refetchInterval: 30000, // Aggiorna ogni 30 secondi
  });

  // Mutation per creare un nuovo peer
  const createPeerMutation = useMutation({
    mutationFn: (data: { name: string; description?: string }) => 
      apiRequest('POST', '/api/wireguard/config', data),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/wireguard/peers'] });
      queryClient.invalidateQueries({ queryKey: ['/api/wireguard/status'] });
      
      // Mostra notifica di successo
      toast({
        title: "Configurazione creata",
        description: "La configurazione WireGuard è stata creata con successo",
      });
      
      // Scarica automaticamente il file di configurazione
      if (data && data.config && data.filename) {
        downloadConfigFile(data.config, data.filename);
      }
      
      // Chiudi il dialog e resetta i campi
      setIsNewConfigOpen(false);
      setNewPeerName('');
      setNewPeerDesc('');
    },
    onError: (error) => {
      console.error('Errore nella creazione del peer:', error);
      toast({
        title: "Errore",
        description: "Impossibile creare la configurazione WireGuard",
        variant: "destructive",
      });
    }
  });

  // Mutation per eliminare un peer
  const deletePeerMutation = useMutation({
    mutationFn: (peerId: number) => 
      apiRequest('DELETE', `/api/wireguard/peers/${peerId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/wireguard/peers'] });
      queryClient.invalidateQueries({ queryKey: ['/api/wireguard/status'] });
      
      toast({
        title: "Configurazione eliminata",
        description: "La configurazione WireGuard è stata eliminata con successo",
      });
      
      setIsConfirmDeleteOpen(false);
      setSelectedPeer(null);
    },
    onError: (error) => {
      console.error('Errore nell\'eliminazione del peer:', error);
      toast({
        title: "Errore",
        description: "Impossibile eliminare la configurazione WireGuard",
        variant: "destructive",
      });
    }
  });

  // Mutation per abilitare/disabilitare un peer
  const togglePeerMutation = useMutation({
    mutationFn: ({ peerId, enabled }: { peerId: number; enabled: boolean }) => 
      apiRequest('PATCH', `/api/wireguard/peers/${peerId}`, { enabled }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/wireguard/peers'] });
      queryClient.invalidateQueries({ queryKey: ['/api/wireguard/status'] });
      
      toast({
        title: "Stato aggiornato",
        description: "Lo stato della configurazione WireGuard è stato aggiornato",
      });
    },
    onError: (error) => {
      console.error('Errore nell\'aggiornamento del peer:', error);
      toast({
        title: "Errore",
        description: "Impossibile aggiornare lo stato della configurazione",
        variant: "destructive",
      });
    }
  });

  // Mutation per rigenerare la configurazione di un peer
  const regenerateConfigMutation = useMutation({
    mutationFn: (peerId: number) => 
      apiRequest('POST', `/api/wireguard/peers/${peerId}/regenerate`),
    onSuccess: (data) => {
      // Scarica automaticamente il file di configurazione
      if (data && data.config && data.filename) {
        downloadConfigFile(data.config, data.filename);
        
        toast({
          title: "Configurazione rigenerata",
          description: "La configurazione WireGuard è stata rigenerata con successo",
        });
      }
    },
    onError: (error) => {
      console.error('Errore nella rigenerazione della configurazione:', error);
      toast({
        title: "Errore",
        description: "Impossibile rigenerare la configurazione WireGuard",
        variant: "destructive",
      });
    }
  });

  // Funzione per scaricare il file di configurazione
  const downloadConfigFile = (configContent: string, filename: string) => {
    const blob = new Blob([configContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Funzione per creare un nuovo peer
  const handleCreatePeer = () => {
    if (!newPeerName.trim()) {
      toast({
        title: "Errore",
        description: "Inserisci un nome per la configurazione",
        variant: "destructive",
      });
      return;
    }

    createPeerMutation.mutate({ 
      name: newPeerName.trim(),
      description: newPeerDesc.trim() || undefined
    });
  };

  // Funzione per eliminare un peer
  const handleDeletePeer = () => {
    if (selectedPeer) {
      deletePeerMutation.mutate(selectedPeer.id);
    }
  };

  // Funzione per abilitare/disabilitare un peer
  const handleTogglePeer = (peer: WireguardPeer) => {
    togglePeerMutation.mutate({ 
      peerId: peer.id, 
      enabled: !peer.enabled 
    });
  };

  // Funzione per rigenerare la configurazione di un peer
  const handleRegenerateConfig = (peerId: number) => {
    regenerateConfigMutation.mutate(peerId);
  };

  // Funzioni per formattare i dati
  const formatBytes = (bytes?: number): string => {
    if (!bytes || bytes === 0) return '0 B';
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return parseFloat((bytes / Math.pow(1024, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDate = (dateString?: string): string => {
    if (!dateString) return 'Mai';
    return new Date(dateString).toLocaleString();
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Configurazioni WireGuard</CardTitle>
          <CardDescription>Gestisci le configurazioni VPN per i tuoi dispositivi</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-center py-8">Caricamento configurazioni...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div>
          <CardTitle>Configurazioni WireGuard</CardTitle>
          <CardDescription>Gestisci le configurazioni VPN per i tuoi dispositivi</CardDescription>
        </div>
        <Button onClick={() => setIsNewConfigOpen(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Nuovo dispositivo
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {peers && peers.length > 0 ? (
            peers.map((peer) => (
              <div key={peer.id} className="border rounded-lg p-4">
                <div className="flex justify-between items-start">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <div className={`w-3 h-3 rounded-full ${peer.isOnline ? 'bg-green-500' : peer.enabled ? 'bg-amber-500' : 'bg-gray-400'}`}></div>
                      <h3 className="font-semibold text-lg">{peer.name}</h3>
                      <Badge variant={peer.enabled ? "default" : "outline"}>
                        {peer.enabled ? "Attivo" : "Disabilitato"}
                      </Badge>
                    </div>
                    {peer.description && (
                      <p className="text-sm text-muted-foreground">{peer.description}</p>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button size="icon" variant="ghost" onClick={() => handleRegenerateConfig(peer.id)} title="Rigenera configurazione">
                      <RefreshCw className="h-4 w-4" />
                    </Button>
                    <Button 
                      size="icon" 
                      variant={peer.enabled ? "ghost" : "outline"} 
                      onClick={() => handleTogglePeer(peer)}
                      title={peer.enabled ? "Disabilita" : "Abilita"}
                    >
                      <Shield className="h-4 w-4" />
                    </Button>
                    <Button 
                      size="icon" 
                      variant="ghost" 
                      className="text-red-500 hover:text-red-700 hover:bg-red-100"
                      onClick={() => {
                        setSelectedPeer(peer);
                        setIsConfirmDeleteOpen(true);
                      }}
                      title="Elimina"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <Separator className="my-3" />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Indirizzo IP:</span>
                      <span className="font-medium">{peer.allowedIps.split('/')[0]}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Creato il:</span>
                      <span>{formatDate(peer.createdAt)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Ultima connessione:</span>
                      <span>{formatDate(peer.lastHandshake)}</span>
                    </div>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Download:</span>
                      <span>{formatBytes(peer.transferRx)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Upload:</span>
                      <span>{formatBytes(peer.transferTx)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Chiave pubblica:</span>
                      <span className="font-mono text-xs">{peer.publicKey.substring(0, 12)}...{peer.publicKey.substring(peer.publicKey.length - 4)}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="border rounded-lg p-8 text-center">
              <p className="text-muted-foreground mb-4">Nessuna configurazione WireGuard trovata</p>
              <Button onClick={() => setIsNewConfigOpen(true)}>Crea la prima configurazione</Button>
            </div>
          )}
        </div>
      </CardContent>
      
      {/* Dialog per nuova configurazione */}
      <Dialog open={isNewConfigOpen} onOpenChange={setIsNewConfigOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Nuova configurazione WireGuard</DialogTitle>
            <DialogDescription>
              Crea una nuova configurazione per il tuo dispositivo. Il file di configurazione verrà scaricato automaticamente.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="name">Nome dispositivo</Label>
              <Input 
                id="name" 
                placeholder="es. iPhone, Laptop, iPad" 
                value={newPeerName}
                onChange={(e) => setNewPeerName(e.target.value)}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description">Descrizione (opzionale)</Label>
              <Input 
                id="description" 
                placeholder="es. Dispositivo personale" 
                value={newPeerDesc}
                onChange={(e) => setNewPeerDesc(e.target.value)}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsNewConfigOpen(false)}>Annulla</Button>
            <Button onClick={handleCreatePeer} disabled={createPeerMutation.isPending}>
              {createPeerMutation.isPending ? "Creazione..." : "Crea e scarica"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Dialog per conferma eliminazione */}
      <Dialog open={isConfirmDeleteOpen} onOpenChange={setIsConfirmDeleteOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Conferma eliminazione</DialogTitle>
            <DialogDescription>
              Sei sicuro di voler eliminare la configurazione <strong>{selectedPeer?.name}</strong>?
              <br />
              Questa azione non può essere annullata e il dispositivo non potrà più connettersi alla rete VPN.
            </DialogDescription>
          </DialogHeader>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsConfirmDeleteOpen(false)}>Annulla</Button>
            <Button 
              variant="destructive" 
              onClick={handleDeletePeer}
              disabled={deletePeerMutation.isPending}
            >
              {deletePeerMutation.isPending ? "Eliminazione..." : "Elimina configurazione"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
};

export default WireguardConfigManager;