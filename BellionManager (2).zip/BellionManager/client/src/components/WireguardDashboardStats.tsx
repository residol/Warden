import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { HelpCircle, Server, Activity, DownloadCloud, UploadCloud, Clock, Users, Zap, Wifi, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';
import { cn } from '@/lib/utils';

// Funzione di utilità per formattare i byte
const formatBytes = (bytes: number, decimals = 2) => {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
};

// Componente per una singola carta di statistica
interface StatCardProps {
  title: string;
  value: string | React.ReactNode;
  description?: string;
  icon: React.ReactNode;
  variant?: 'default' | 'primary' | 'success' | 'warning' | 'danger';
  loading?: boolean;
}

const StatCard: React.FC<StatCardProps> = ({ 
  title, 
  value, 
  description, 
  icon, 
  variant = 'default',
  loading = false
}) => {
  const getVariantStyles = () => {
    switch (variant) {
      case 'primary':
        return 'bg-primary/10 text-primary border-primary/30';
      case 'success':
        return 'bg-green-500/10 text-green-500 border-green-500/30';
      case 'warning':
        return 'bg-yellow-500/10 text-yellow-500 border-yellow-500/30';
      case 'danger':
        return 'bg-destructive/10 text-destructive border-destructive/30';
      default:
        return 'bg-card border-border';
    }
  };

  return (
    <Card className={cn("border overflow-hidden transition-all", getVariantStyles())}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="text-sm font-medium">{title}</div>
          <div className="text-muted-foreground/60">{icon}</div>
        </div>
        {loading ? (
          <>
            <Skeleton className="h-8 w-32 mb-2" />
            {description && <Skeleton className="h-4 w-24" />}
          </>
        ) : (
          <>
            <div className="text-2xl font-bold mb-1">{value}</div>
            {description && (
              <p className="text-xs text-muted-foreground">{description}</p>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
};

// Componente principale
const WireguardDashboardStats: React.FC = () => {
  // Query per lo stato WireGuard
  const { data: wireguardStatus, isLoading: isLoadingWireguard } = useQuery<WireguardStatus>({
    queryKey: ['/api/wireguard/status'],
    refetchInterval: 15000 // Aggiorna ogni 15 secondi
  });

  // Query per le statistiche aggregate di utilizzo
  const { data: usageStats, isLoading: isLoadingStats } = useQuery({
    queryKey: ['/api/wireguard/usage-stats'],
    refetchInterval: 60000 // Aggiorna ogni minuto
  });

  // Query per tutti i peer
  const { data: peers, isLoading: isLoadingPeers } = useQuery({
    queryKey: ['/api/wireguard/peers'],
    refetchInterval: 30000 // Aggiorna ogni 30 secondi
  });

  // Calcola statistiche derivate
  const getOnlineStatus = () => {
    if (isLoadingWireguard || !wireguardStatus) return { label: 'Caricamento...', variant: 'default' as const };
    
    if (wireguardStatus.status === 'online') {
      return { 
        label: 'Online', 
        variant: 'success' as const,
        icon: <CheckCircle className="h-5 w-5" />
      };
    } else if (wireguardStatus.status === 'degraded') {
      return { 
        label: 'Degradato', 
        variant: 'warning' as const,
        icon: <AlertTriangle className="h-5 w-5" />
      };
    } else {
      return { 
        label: 'Offline', 
        variant: 'danger' as const,
        icon: <XCircle className="h-5 w-5" />
      };
    }
  };

  const getOnlinePeers = () => {
    if (isLoadingPeers || !peers) return 0;
    return peers.filter((peer: any) => peer.isOnline).length;
  };

  const getTotalPeers = () => {
    if (isLoadingPeers || !peers) return 0;
    return peers.length;
  };

  const getLastHandshake = () => {
    if (isLoadingPeers || !peers) return 'N/A';
    
    // Trova il peer con l'handshake più recente
    const onlinePeers = peers.filter((peer: any) => peer.isOnline);
    if (onlinePeers.length === 0) return 'Nessun peer online';
    
    // Ordina i peer per timestamp dell'ultimo handshake (dal più recente)
    const sortedPeers = [...onlinePeers].sort((a, b) => {
      const dateA = a.lastHandshake ? new Date(a.lastHandshake).getTime() : 0;
      const dateB = b.lastHandshake ? new Date(b.lastHandshake).getTime() : 0;
      return dateB - dateA;
    });
    
    const mostRecent = sortedPeers[0];
    if (!mostRecent.lastHandshake) return 'Mai';
    
    // Formatta il timestamp relativo
    const date = new Date(mostRecent.lastHandshake);
    const now = new Date();
    const diffSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffSeconds < 60) return `${diffSeconds} secondi fa`;
    if (diffSeconds < 3600) return `${Math.floor(diffSeconds / 60)} minuti fa`;
    if (diffSeconds < 86400) return `${Math.floor(diffSeconds / 3600)} ore fa`;
    return `${Math.floor(diffSeconds / 86400)} giorni fa`;
  };

  const onlineStatus = getOnlineStatus();

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      {/* Stato WireGuard */}
      <StatCard
        title="Stato WireGuard"
        value={
          <div className="flex items-center">
            {onlineStatus.label}
            <Badge variant={onlineStatus.variant} className="ml-2 px-1.5 py-0">
              {wireguardStatus?.interface?.substring(0, 4) || 'wg0'}
            </Badge>
          </div>
        }
        description={wireguardStatus?.listenPort ? `Porta: ${wireguardStatus.listenPort}` : undefined}
        icon={<Server className="h-5 w-5" />}
        variant={onlineStatus.variant}
        loading={isLoadingWireguard}
      />

      {/* Dispositivi Connessi */}
      <StatCard
        title="Dispositivi"
        value={`${getOnlinePeers()} / ${getTotalPeers()}`}
        description="Dispositivi connessi"
        icon={<Users className="h-5 w-5" />}
        variant={getOnlinePeers() > 0 ? 'primary' : 'default'}
        loading={isLoadingPeers}
      />

      {/* Ultimo Handshake */}
      <StatCard
        title="Ultima Attività"
        value={getLastHandshake()}
        description="Ultimo handshake registrato"
        icon={<Clock className="h-5 w-5" />}
        loading={isLoadingPeers}
      />

      {/* Traffico Totale */}
      <StatCard
        title="Traffico Totale"
        value={usageStats ? formatBytes(usageStats.totalTraffic) : '0 B'}
        description={
          usageStats ? 
          `↓ ${formatBytes(usageStats.totalDownload)} ↑ ${formatBytes(usageStats.totalUpload)}` : 
          undefined
        }
        icon={<Activity className="h-5 w-5" />}
        loading={isLoadingStats}
      />
    </div>
  );
};

export default WireguardDashboardStats;