import React from 'react';

interface WelcomeMessageProps {
  onGuideClick: () => void;
  onAccessClick: () => void;
}

const WelcomeMessage: React.FC<WelcomeMessageProps> = ({ onGuideClick, onAccessClick }) => {
  return (
    <div className="mb-6 border-l-4 border-discord-blurple bg-discord-input rounded-r-md p-4">
      <h2 className="text-xl font-semibold mb-2">👋 Benvenuto nei Giardini di Bellion</h2>
      <p className="text-discord-muted mb-4">
        Questa è la tua porta d'accesso alla LAN virtuale basata su WireGuard. Qui puoi visualizzare tutti i server disponibili, 
        controllare chi è online, e gestire le tue connessioni.
      </p>
      <div className="flex space-x-2">
        <button 
          className="bg-discord-blurple hover:bg-opacity-80 px-4 py-2 rounded-md text-white flex items-center"
          onClick={onGuideClick}
        >
          <i className="fas fa-book mr-2"></i> Leggi la guida
        </button>
        <button 
          className="bg-discord-green hover:bg-opacity-80 px-4 py-2 rounded-md text-white flex items-center"
          onClick={onAccessClick}
        >
          <i className="fas fa-user-plus mr-2"></i> Ottieni accesso
        </button>
      </div>
    </div>
  );
}

export default WelcomeMessage;
