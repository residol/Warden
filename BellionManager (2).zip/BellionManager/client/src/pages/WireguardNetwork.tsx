import React from 'react';
import WireguardNetworkVisualizer from '../components/WireguardNetworkVisualizer';
import WireguardConfigManager from '../components/WireguardConfigManager';
import WireguardFirewallRules from '../components/WireguardFirewallRules';
import WireguardBackupManager from '../components/WireguardBackupManager';
import WireguardUsageHistory from '../components/WireguardUsageHistory';
import WireguardDashboardStats from '../components/WireguardDashboardStats';
import { useQuery } from '@tanstack/react-query';
import { Separator } from "@/components/ui/separator";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Shield, AlertTriangle, ArrowDown, ArrowUp } from 'lucide-react';
import { WireguardStatus } from '@/lib/types';

// Funzione per formattare i byte
const formatBytes = (bytes?: number): string => {
  if (!bytes || bytes === 0) return '0 B';
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return parseFloat((bytes / Math.pow(1024, i)).toFixed(2)) + ' ' + sizes[i];
};

// Funzione per determinare lo stato di sicurezza di un peer
const getPeerSecurityStatus = (lastHandshake: string): { status: 'ok' | 'warning' | 'danger'; message: string } => {
  const lastHandshakeDate = new Date(lastHandshake);
  const now = new Date();
  const diffMs = now.getTime() - lastHandshakeDate.getTime();
  const diffHours = diffMs / (1000 * 60 * 60);
  
  if (diffHours < 1) {
    return { status: 'ok', message: 'Connessione recente, sicurezza ottimale' };
  } else if (diffHours < 24) {
    return { status: 'warning', message: 'Connessione nelle ultime 24 ore, controllare lo stato' };
  } else {
    return { status: 'danger', message: 'Connessione obsoleta, considerare la rimozione del peer' };
  }
};

const WireguardNetworkPage: React.FC = () => {
  // Ottieni i dati sulla rete WireGuard
  const { data: wireguardStatus, isLoading, error } = useQuery<WireguardStatus>({
    queryKey: ['/api/wireguard/status'],
    refetchInterval: 30000, // Aggiorna ogni 30 secondi
  });

  // Ottieni i dati sulle regole firewall (esempio, in un'implementazione reale questi dati verrebbero da un'API)
  const { data: firewallRules } = useQuery({
    queryKey: ['/api/wireguard/firewall'],
    refetchInterval: 60000, // Aggiorna ogni minuto
  });

  if (isLoading) {
    return <div className="container mx-auto p-4">Caricamento in corso...</div>;
  }

  if (error || !wireguardStatus) {
    return <div className="container mx-auto p-4">Si è verificato un errore nel caricamento dei dati.</div>;
  }

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-6">Gestione Rete WireGuard</h1>
      
      <div className="grid grid-cols-1 gap-8">
        {/* Dashboard statistiche */}
        <WireguardDashboardStats />
        
        {/* Visualizzazione grafica della rete */}
        <WireguardNetworkVisualizer />
        
        {/* Gestore configurazioni */}
        <WireguardConfigManager />
        
        {/* Analisi di sicurezza */}
        <Card>
          <CardHeader>
            <CardTitle>Analisi di Sicurezza</CardTitle>
            <CardDescription>Controllo dello stato di sicurezza dei peer WireGuard</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Peer</TableHead>
                  <TableHead>Stato</TableHead>
                  <TableHead>Ultimo Handshake</TableHead>
                  <TableHead>Raccomandazione</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {wireguardStatus.peers.map((peer, index) => {
                  const security = getPeerSecurityStatus(peer.latestHandshake);
                  return (
                    <TableRow key={index}>
                      <TableCell className="font-medium">{peer.name || peer.allowedIps.split('/')[0]}</TableCell>
                      <TableCell>
                        {security.status === 'ok' && <Shield className="inline text-green-500 mr-2" size={16} />}
                        {security.status === 'warning' && <AlertTriangle className="inline text-amber-500 mr-2" size={16} />}
                        {security.status === 'danger' && <AlertTriangle className="inline text-red-500 mr-2" size={16} />}
                        {security.status}
                      </TableCell>
                      <TableCell>{new Date(peer.latestHandshake).toLocaleString()}</TableCell>
                      <TableCell>{security.message}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
        
        {/* Regole Firewall */}
        <Card>
          <CardHeader>
            <CardTitle>Regole Firewall</CardTitle>
            <CardDescription>Limitazioni di traffico applicate ai peer</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-sm p-4 bg-amber-50 border border-amber-200 rounded-md mb-4">
              <AlertTriangle className="inline mr-2 text-amber-500" size={16} />
              Le regole firewall sono simulate e non sono realmente implementate. In un ambiente di produzione, queste regole sarebbero applicate tramite iptables o nftables.
            </div>
            
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Peer</TableHead>
                  <TableHead><ArrowDown className="inline mr-1" size={14} /> Limite Download</TableHead>
                  <TableHead><ArrowUp className="inline mr-1" size={14} /> Limite Upload</TableHead>
                  <TableHead>Porte consentite</TableHead>
                  <TableHead>Stato</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {wireguardStatus.peers.map((peer, index) => (
                  <TableRow key={index}>
                    <TableCell className="font-medium">{peer.name || peer.allowedIps.split('/')[0]}</TableCell>
                    <TableCell>10 Mbps</TableCell>
                    <TableCell>5 Mbps</TableCell>
                    <TableCell>22, 80, 443, 25565</TableCell>
                    <TableCell>
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        Attivo
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
        
        {/* Statistiche di utilizzo */}
        <Card>
          <CardHeader>
            <CardTitle>Statistiche di Utilizzo</CardTitle>
            <CardDescription>Traffico e utilizzo della rete WireGuard</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {wireguardStatus.peers.map((peer, index) => (
                <div key={index} className="p-4 border rounded-lg">
                  <h3 className="text-lg font-semibold mb-2">{peer.name || peer.allowedIps.split('/')[0]}</h3>
                  <Separator className="my-2" />
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Download:</span>
                      <span className="font-medium">{formatBytes(peer.transferRx)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Upload:</span>
                      <span className="font-medium">{formatBytes(peer.transferTx)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Totale:</span>
                      <span className="font-medium">{formatBytes((peer.transferRx || 0) + (peer.transferTx || 0))}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Connessioni:</span>
                      <span className="font-medium">{peer.totalConnections || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Ultima durata:</span>
                      <span className="font-medium">
                        {peer.lastConnectionDuration 
                          ? `${Math.floor(peer.lastConnectionDuration / 3600)}h ${Math.floor((peer.lastConnectionDuration % 3600) / 60)}m` 
                          : 'N/A'}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        
        {/* Regole Firewall */}
        <WireguardFirewallRules />
        
        {/* Storico di utilizzo */}
        <WireguardUsageHistory />
        
        {/* Gestione Backup */}
        <WireguardBackupManager />
      </div>
    </div>
  );
};

export default WireguardNetworkPage;