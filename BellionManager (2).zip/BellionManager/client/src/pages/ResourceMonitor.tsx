import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';

// Components
import Sidebar from '@/components/Sidebar';
import ChannelHeader from '@/components/ChannelHeader';
import StatusBar from '@/components/StatusBar';
import PterodactylResourcesCard from '@/components/PterodactylResourcesCard';
import ResourceHistory from '@/components/ResourceHistory';

const ResourceMonitor: React.FC = () => {
  // Stato per server selezionato
  const [selectedServer, setSelectedServer] = useState<string | null>(null);
  
  // Stato per il canale selezionato
  const [selectedChannel, setSelectedChannel] = useState<{ category: string; channel: string }>({
    category: 'Comandi Bot',
    channel: 'lan-status'
  });

  // Fetch WireGuard status
  const { data: wireguardStatusData, isLoading: isLoadingWireguard } = useQuery<any>({
    queryKey: ['/api/wireguard/status'],
    refetchInterval: 10000
  });
  
  // Ensure well-typed wireguard status
  const typedWireguardStatus = {
    status: (wireguardStatusData?.status === 'online' || wireguardStatusData?.status === 'offline') 
      ? wireguardStatusData.status 
      : 'degraded',
    totalTraffic: wireguardStatusData?.totalTraffic || '0 GB',
    peers: wireguardStatusData?.peers || []
  };

  // Sidebar data
  const sidebarCategories = [
    {
      name: 'Porte del giardino',
      icon: 'chevron-down',
      channels: [
        { id: 'benvenuto', name: 'benvenuto', type: "text" as const },
        { id: 'ruoli', name: 'ruoli', type: "text" as const },
        { id: 'annunci', name: 'annunci', type: "text" as const }
      ]
    },
    {
      name: 'Giardini di Bellion',
      icon: 'chevron-down',
      channels: [
        { id: 'minecraft', name: 'minecraft', type: "text" as const },
        { id: 'rust', name: 'rust', type: "text" as const },
        { id: 'minecraft-voice', name: 'Minecraft Voice', type: "voice" as const, users: 3 }
      ]
    },
    {
      name: 'Comandi Bot',
      icon: 'chevron-down',
      channels: [
        { id: 'bot-commands', name: 'bot-commands', type: "text" as const },
        { id: 'lan-status', name: 'lan-status', type: "text" as const },
        { id: 'resource-monitor', name: 'resource-monitor', type: "text" as const }
      ]
    }
  ];

  // Channel selection handler
  const handleChannelSelect = (categoryName: string, channelName: string) => {
    setSelectedChannel({ category: categoryName, channel: channelName });
  };

  // Function to handle server selection for detailed view
  const handleServerSelect = (serverId: string) => {
    setSelectedServer(serverId === selectedServer ? null : serverId);
  };

  return (
    <div className="flex h-screen">
      {/* Sidebar */}
      <Sidebar 
        categories={sidebarCategories} 
        onChannelSelect={handleChannelSelect}
        selectedChannel={selectedChannel}
      />

      {/* Main content area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Channel header */}
        <ChannelHeader 
          channelName="resource-monitor" 
          channelDescription="Monitoraggio risorse Pterodactyl - Visualizza l'utilizzo delle risorse dei server di gioco"
        />

        {/* Main content with scrolling */}
        <div className="flex-1 overflow-y-auto p-4 space-y-6">
          <div className="bg-discord-dark p-4 rounded-md mb-6">
            <h2 className="text-xl font-semibold mb-2">
              <i className="fas fa-chart-line text-discord-blurple mr-2"></i> 
              Monitoraggio Risorse Pterodactyl
            </h2>
            <p className="text-sm text-discord-muted">
              Questa pagina mostra l'utilizzo in tempo reale delle risorse (CPU, Memoria, Disco) dei server di gioco ospitati sul pannello Pterodactyl.
              Gli indicatori colorati mostrano lo stato delle risorse:
              <span className="inline-block mx-1 px-2 py-1 rounded bg-green-500 text-white">✓ Normale</span>
              <span className="inline-block mx-1 px-2 py-1 rounded bg-yellow-500 text-white">⚠️ Avviso</span>
              <span className="inline-block mx-1 px-2 py-1 rounded bg-red-500 text-white">🔴 Critico</span>
            </p>
          </div>

          {/* Current Resource Usage */}
          <div>
            <h3 className="text-lg font-medium mb-3">Utilizzo Risorse Attuale</h3>
            <PterodactylResourcesCard onRefresh={() => {}} />
          </div>

          {/* Resource History */}
          <div>
            <h3 className="text-lg font-medium mb-3">Storico Utilizzo Risorse</h3>
            <ResourceHistory serverId={selectedServer || undefined} />
          </div>

          {/* Resource Monitoring Configuration */}
          <div className="bg-discord-sidebar rounded-md overflow-hidden mb-6">
            <div className="bg-discord-dark px-4 py-3">
              <h3 className="font-semibold flex items-center">
                <i className="fas fa-cog text-discord-blurple mr-2"></i> Configurazione Monitoraggio
              </h3>
            </div>
            
            <div className="p-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-discord-dark p-4 rounded-md">
                  <h4 className="font-medium mb-2">Soglie CPU</h4>
                  <div className="space-y-3">
                    <div>
                      <label className="text-xs text-discord-muted block mb-1">Soglia Avviso (%)</label>
                      <input 
                        type="range" 
                        min="50" 
                        max="90" 
                        defaultValue="70" 
                        className="w-full"
                      />
                      <div className="flex justify-between text-xs text-discord-muted">
                        <span>50%</span>
                        <span>70%</span>
                        <span>90%</span>
                      </div>
                    </div>
                    <div>
                      <label className="text-xs text-discord-muted block mb-1">Soglia Critica (%)</label>
                      <input 
                        type="range" 
                        min="70" 
                        max="100" 
                        defaultValue="90" 
                        className="w-full"
                      />
                      <div className="flex justify-between text-xs text-discord-muted">
                        <span>70%</span>
                        <span>90%</span>
                        <span>100%</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="bg-discord-dark p-4 rounded-md">
                  <h4 className="font-medium mb-2">Soglie Memoria</h4>
                  <div className="space-y-3">
                    <div>
                      <label className="text-xs text-discord-muted block mb-1">Soglia Avviso (%)</label>
                      <input 
                        type="range" 
                        min="50" 
                        max="90" 
                        defaultValue="80" 
                        className="w-full"
                      />
                      <div className="flex justify-between text-xs text-discord-muted">
                        <span>50%</span>
                        <span>80%</span>
                        <span>90%</span>
                      </div>
                    </div>
                    <div>
                      <label className="text-xs text-discord-muted block mb-1">Soglia Critica (%)</label>
                      <input 
                        type="range" 
                        min="70" 
                        max="100" 
                        defaultValue="95" 
                        className="w-full"
                      />
                      <div className="flex justify-between text-xs text-discord-muted">
                        <span>70%</span>
                        <span>95%</span>
                        <span>100%</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="bg-discord-dark p-4 rounded-md">
                  <h4 className="font-medium mb-2">Impostazioni Generali</h4>
                  <div className="space-y-3">
                    <div>
                      <label className="text-xs text-discord-muted block mb-1">Intervallo Controllo (minuti)</label>
                      <select className="w-full bg-discord-sidebar text-discord-muted p-2 rounded text-sm">
                        <option value="1">1 minuto</option>
                        <option value="5" selected>5 minuti</option>
                        <option value="10">10 minuti</option>
                        <option value="15">15 minuti</option>
                        <option value="30">30 minuti</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-xs text-discord-muted block mb-1">Notifiche</label>
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" checked className="h-4 w-4" id="notifyDiscord" />
                        <label htmlFor="notifyDiscord" className="text-sm">Discord</label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="mt-4 flex justify-end">
                <button className="bg-discord-blurple hover:bg-opacity-80 text-white px-4 py-2 rounded text-sm">
                  Salva Configurazione
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Status bar */}
        <StatusBar 
          wireguardStatus={typedWireguardStatus.status}
          pterodactylStatus="connected"
          serverIp={"65.108.8.246"}
          usersConnected={typedWireguardStatus.peers.length}
        />
      </div>
    </div>
  );
};

export default ResourceMonitor;