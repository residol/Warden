import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Link } from 'wouter';

// Components
import Sidebar from '@/components/Sidebar';
import SideNav from '@/components/SideNav';
import ChannelHeader from '@/components/ChannelHeader';
import WelcomeMessage from '@/components/WelcomeMessage';
import ServerStatusCard, { ServerInfo } from '@/components/ServerStatusCard';
import LanStatusCard, { WireguardPeer } from '@/components/LanStatusCard';
import MembersSidebar, { UserInfo } from '@/components/MembersSidebar';
import StatusBar from '@/components/StatusBar';
import CommandsExample from '@/components/CommandsExample';
import RoleModal from '@/components/RoleModal';
import AlertModal, { SystemAlert } from '@/components/AlertModal';
import WireGuardConfigModal from '@/components/WireGuardConfigModal';
import MigrationModal from '@/components/MigrationModal';
import PterodactylResourcesCard from '@/components/PterodactylResourcesCard';

// Icons
import { Network, ArrowRight } from 'lucide-react';

const Dashboard: React.FC = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // State for selected channel
  const [selectedChannel, setSelectedChannel] = useState<{ category: string; channel: string }>({
    category: 'Giardini di Bellion',
    channel: 'minecraft'
  });

  // State for modals
  const [isRoleModalOpen, setIsRoleModalOpen] = useState(false);
  const [isAlertModalOpen, setIsAlertModalOpen] = useState(false);
  const [isWgConfigModalOpen, setIsWgConfigModalOpen] = useState(false);
  const [isMigrationModalOpen, setIsMigrationModalOpen] = useState(false);
  const [currentAlert, setCurrentAlert] = useState<SystemAlert | null>(null);
  const [generatedConfig, setGeneratedConfig] = useState<string | null>(null);

  // Definizione dei tipi per i dati API
  interface ApiServer extends ServerInfo {}
  
  interface ApiWireguardStatus {
    status: 'online' | 'offline' | 'degraded';
    totalTraffic: string;
    peers: Array<{
      publicKey: string;
      allowedIps: string;
      latestHandshake: string;
    }>;
  }
  
  interface ApiAlert {
    id: number;
    type: string;
    message: string;
    serverId?: number;
    acknowledged: boolean;
    createdAt: string;
  }

  // Fetch servers data
  const { data: servers = [] as ApiServer[], isLoading: isLoadingServers } = useQuery<ApiServer[]>({
    queryKey: ['/api/servers'],
    refetchInterval: 10000 // Refresh every 10 seconds
  });

  // Fetch WireGuard status
  const { data: wireguardStatusData, isLoading: isLoadingWireguard } = useQuery<any>({
    queryKey: ['/api/wireguard/status'],
    refetchInterval: 10000
  });
  
  // Fetch system alerts
  const { data: alerts = [] as ApiAlert[], isLoading: isLoadingAlerts } = useQuery<ApiAlert[]>({
    queryKey: ['/api/alerts'],
    refetchInterval: 10000
  });

  // Server action mutations
  const startServerMutation = useMutation({
    mutationFn: (serverId: number) => 
      apiRequest('POST', `/api/servers/${serverId}/start`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/servers'] });
      toast({
        title: "Server avviato",
        description: "Il server è in fase di avvio",
      });
    },
    onError: (error) => {
      toast({
        title: "Errore",
        description: "Impossibile avviare il server",
        variant: "destructive",
      });
    }
  });

  const stopServerMutation = useMutation({
    mutationFn: (serverId: number) => 
      apiRequest('POST', `/api/servers/${serverId}/stop`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/servers'] });
      toast({
        title: "Server arrestato",
        description: "Il server è in fase di arresto",
      });
    },
    onError: (error) => {
      toast({
        title: "Errore",
        description: "Impossibile arrestare il server",
        variant: "destructive",
      });
    }
  });

  const restartServerMutation = useMutation({
    mutationFn: (serverId: number) => 
      apiRequest('POST', `/api/servers/${serverId}/restart`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/servers'] });
      toast({
        title: "Server riavviato",
        description: "Il server è in fase di riavvio",
      });
    },
    onError: (error) => {
      toast({
        title: "Errore",
        description: "Impossibile riavviare il server",
        variant: "destructive",
      });
    }
  });

  const acknowledgeAlertMutation = useMutation({
    mutationFn: (alertId: number) => 
      apiRequest('POST', `/api/alerts/${alertId}/acknowledge`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/alerts'] });
    },
    onError: (error) => {
      toast({
        title: "Errore",
        description: "Impossibile riconoscere l'avviso",
        variant: "destructive",
      });
    }
  });

  // Handle new alert notifications
  useEffect(() => {
    const unacknowledgedAlerts = (alerts as any[])?.filter(alert => !alert.acknowledged);
    if (unacknowledgedAlerts?.length > 0 && !isAlertModalOpen) {
      const latestAlert: SystemAlert = {
        id: unacknowledgedAlerts[0].id,
        type: unacknowledgedAlerts[0].type,
        title: `Problema rilevato: ${unacknowledgedAlerts[0].message.split(':')[0]}`,
        message: unacknowledgedAlerts[0].message,
        timestamp: new Date(unacknowledgedAlerts[0].createdAt).toLocaleTimeString(),
        serverName: unacknowledgedAlerts[0].serverId ? 
          servers.find((s: any) => s.id === unacknowledgedAlerts[0].serverId)?.name : undefined
      };
      
      setCurrentAlert(latestAlert);
      setIsAlertModalOpen(true);
    }
  }, [alerts, isAlertModalOpen, servers]);

  // Mock data for sidebar
  const sidebarCategories = [
    {
      name: 'Porte del giardino',
      icon: 'chevron-down',
      channels: [
        { id: 'benvenuto', name: 'benvenuto', type: "text" as const },
        { id: 'ruoli', name: 'ruoli', type: "text" as const },
        { id: 'annunci', name: 'annunci', type: "text" as const }
      ]
    },
    {
      name: 'Giardini di Bellion',
      icon: 'chevron-down',
      channels: [
        { id: 'minecraft', name: 'minecraft', type: "text" as const },
        { id: 'rust', name: 'rust', type: "text" as const },
        { id: 'minecraft-voice', name: 'Minecraft Voice', type: "voice" as const, users: 3 }
      ]
    },
    {
      name: 'Comandi Bot',
      icon: 'chevron-down',
      channels: [
        { id: 'bot-commands', name: 'bot-commands', type: "text" as const },
        { id: 'lan-status', name: 'lan-status', type: "text" as const }
      ]
    }
  ];

  // Mock users for member sidebar
  const users: UserInfo[] = [
    {
      id: '1',
      username: 'Admin',
      status: 'online',
      isAdmin: true
    },
    {
      id: '2',
      username: 'User1',
      status: 'online',
      isSupporter: true
    },
    {
      id: '3',
      username: 'User2',
      status: 'online',
      isSupporter: true
    },
    {
      id: '4',
      username: 'User3',
      status: 'online',
      isLanMember: true
    },
    {
      id: '5',
      username: 'User4',
      status: 'online',
      isLanMember: true
    },
    {
      id: '6',
      username: 'User5',
      status: 'online',
      isLanMember: true,
      activity: 'Online - In gioco'
    }
  ];

  // Mock commands examples
  const commandExamples = [
    {
      command: 'help',
      title: 'Help - Comandi Disponibili',
      icon: 'question-circle',
      color: 'discord-blurple',
      timestamp: 'Oggi alle 15:30',
      description: (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
          <div>
            <div className="font-medium">/ping</div>
            <div className="text-discord-muted text-xs">Controlla la latenza del bot</div>
          </div>
          <div>
            <div className="font-medium">/servers</div>
            <div className="text-discord-muted text-xs">Elenca i server Pterodactyl online</div>
          </div>
          <div>
            <div className="font-medium">/players</div>
            <div className="text-discord-muted text-xs">Mostra chi è connesso alla LAN</div>
          </div>
          <div>
            <div className="font-medium">/donate</div>
            <div className="text-discord-muted text-xs">Link per supportare il progetto</div>
          </div>
          <div>
            <div className="font-medium">/grant-supporter</div>
            <div className="text-discord-muted text-xs">Assegna/rimuove il ruolo Sostenitore (admin)</div>
          </div>
          <div>
            <div className="font-medium">/guida</div>
            <div className="text-discord-muted text-xs">Istruzioni firewall per la LAN</div>
          </div>
        </div>
      )
    },
    {
      command: 'guida',
      title: 'Guida Firewall per la LAN',
      icon: 'wrench',
      color: 'discord-yellow',
      timestamp: 'Oggi alle 15:32',
      description: (
        <>
          <p className="mb-3">Per connetterti correttamente via WireGuard, segui questi passaggi:</p>
          
          <ol className="list-decimal pl-5 mb-3 space-y-1">
            <li>Installa il client WireGuard sul tuo dispositivo.</li>
            <li>Importa il file di configurazione <code className="bg-discord-dark px-1 rounded text-xs">.conf</code> fornito.</li>
            <li>Apri queste porte sul firewall del tuo client:</li>
          </ol>
          
          <div className="bg-discord-dark p-3 rounded mb-3">
            <ul className="list-disc pl-5 space-y-1">
              <li>UDP 51820 (porta predefinita WireGuard)</li>
              <li>TCP 25565 (Minecraft)</li>
              <li>TCP 27015 (Rust)</li>
            </ul>
          </div>
          
          <h5 className="font-medium mb-2">Windows Firewall</h5>
          <p className="text-discord-muted mb-3">
            Apri Pannello di Controllo &gt; Sistema e sicurezza &gt; Windows Defender Firewall.<br/>
            Vai su Impostazioni avanzate &gt; Regole connessioni in entrata &gt; Nuova regola.<br/>
            Seleziona Porta, scegli UDP, inserisci 51820 e abilita il traffico.<br/>
            Ripeti per le porte di gioco (TCP 25565 e 27015).
          </p>
          
          <h5 className="font-medium mb-2">Linux (ufw)</h5>
          <div className="bg-discord-dark p-3 rounded font-mono text-xs">
            sudo ufw allow 51820/udp<br/>
            sudo ufw allow 25565/tcp<br/>
            sudo ufw allow 27015/tcp<br/>
            sudo ufw reload
          </div>
        </>
      )
    },
    {
      command: 'donate',
      title: 'Supporta il Progetto',
      icon: 'heart',
      color: 'yellow-500',
      timestamp: 'Oggi alle 15:35',
      description: (
        <>
          <p className="mb-4 text-sm">Aiutaci a mantenere attiva l'infrastruttura e a sviluppare nuove funzionalità!</p>
          <a href="https://ko-fi.com/residol" target="_blank" className="inline-flex items-center bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded transition-colors">
            <i className="fas fa-mug-hot mr-2"></i> Supportaci su Ko-fi
          </a>
          <p className="mt-3 text-xs text-discord-muted">I sostenitori ricevono il ruolo speciale "Sostenitore" e accesso a funzionalità esclusive.</p>
        </>
      )
    }
  ];

  // Derived data
  const onlineServers = servers.filter((server) => server.status === 'online');
  
  // Trasforma i dati grezzi di WireGuard in un formato tipizzato
  const typedWireguardStatus: ApiWireguardStatus = {
    status: (wireguardStatusData?.status === 'online' || wireguardStatusData?.status === 'offline') 
      ? wireguardStatusData.status 
      : 'degraded',
    totalTraffic: wireguardStatusData?.totalTraffic || '0 GB',
    peers: wireguardStatusData?.peers || []
  };
  
  // Trasforma i peer WireGuard nel formato richiesto dal componente
  const wireguardPeers: WireguardPeer[] = (typedWireguardStatus.peers || []).map((peer: any, index: number) => ({
    id: index + 1,
    name: `User${index + 1}`,
    ipAddress: peer.allowedIps?.split('/')[0] || `10.99.0.${10 + index}`,
    isOnline: true,
    lastSeen: peer.latestHandshake
  }));

  // Channel selection handler
  const handleChannelSelect = (categoryName: string, channelName: string) => {
    setSelectedChannel({ category: categoryName, channel: channelName });
  };

  // Server action handlers
  const handleStartServer = (id: number) => {
    startServerMutation.mutate(id);
  };

  const handleStopServer = (id: number) => {
    stopServerMutation.mutate(id);
  };

  const handleRestartServer = (id: number) => {
    restartServerMutation.mutate(id);
  };

  const handleServerInfo = (id: number) => {
    toast({
      title: "Info server",
      description: `Informazioni dettagliate per il server ID: ${id}`,
    });
  };

  // Modal handlers
  const handleRoleConfirm = () => {
    toast({
      title: "Ruolo assegnato",
      description: "Hai ottenuto il ruolo LAN",
    });
    setIsRoleModalOpen(false);
  };

  const handleAlertAction = () => {
    if (currentAlert?.serverName) {
      const server = servers.find((s: any) => s.name === currentAlert.serverName);
      if (server) {
        handleRestartServer(server.id);
      }
    }
    
    if (currentAlert) {
      acknowledgeAlertMutation.mutate(currentAlert.id);
    }
    
    setIsAlertModalOpen(false);
  };

  const handleAlertIgnore = () => {
    if (currentAlert) {
      acknowledgeAlertMutation.mutate(currentAlert.id);
    }
    setIsAlertModalOpen(false);
  };

  const handleWgConfigGenerated = (config: string) => {
    setGeneratedConfig(config);
    toast({
      title: "Configurazione generata",
      description: "La configurazione WireGuard è stata generata con successo",
    });
  };

  return (
    <div className="flex h-screen">
      {/* Sidebar */}
      <Sidebar 
        categories={sidebarCategories} 
        onChannelSelect={handleChannelSelect}
        selectedChannel={selectedChannel}
      />

      {/* Main content area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Channel header */}
        <ChannelHeader 
          channelName={selectedChannel.channel} 
          channelDescription={`Server ${selectedChannel.channel.charAt(0).toUpperCase() + selectedChannel.channel.slice(1)} LAN - Discussioni e comandi`}
        />

        {/* Chat area with scrolling */}
        <div className="flex-1 overflow-y-auto p-4 space-y-6">
          {/* Welcome message */}
          <WelcomeMessage 
            onGuideClick={() => setIsWgConfigModalOpen(true)} 
            onAccessClick={() => setIsRoleModalOpen(true)} 
          />

          {/* Server Status List */}
          <div className="bg-discord-sidebar rounded-md overflow-hidden mb-6">
            <div className="bg-discord-dark px-4 py-3 flex items-center justify-between">
              <h3 className="font-semibold flex items-center">
                <i className="fas fa-server text-discord-blurple mr-2"></i> Server Disponibili
              </h3>
              <button 
                className="text-xs bg-discord-input hover:bg-opacity-80 px-2 py-1 rounded text-discord-muted"
                onClick={() => queryClient.invalidateQueries({ queryKey: ['/api/servers'] })}
              >
                Aggiorna
              </button>
            </div>
            
            <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
              {isLoadingServers ? (
                <div className="col-span-2 text-center py-4 text-discord-muted">
                  <i className="fas fa-spinner fa-spin mr-2"></i> Caricamento server...
                </div>
              ) : servers.length > 0 ? (
                servers.map((server: ServerInfo) => (
                  <ServerStatusCard 
                    key={server.id}
                    server={server}
                    onRestart={handleRestartServer}
                    onStart={handleStartServer}
                    onStop={handleStopServer}
                    onInfo={handleServerInfo}
                  />
                ))
              ) : (
                <div className="col-span-2 text-center py-4 text-discord-muted">
                  Nessun server disponibile
                </div>
              )}
            </div>
          </div>

          {/* LAN Status */}
          <LanStatusCard 
            peersCount={wireguardPeers.length}
            totalTraffic={isLoadingWireguard ? "..." : typedWireguardStatus.totalTraffic}
            activeServers={`${onlineServers.length}/${servers.length}`}
            peers={wireguardPeers}
            status={typedWireguardStatus.status}
          />
          
          {/* Pterodactyl Resources Monitoring */}
          {selectedChannel.channel === 'lan-status' && (
            <PterodactylResourcesCard 
              onRefresh={() => {
                queryClient.invalidateQueries({ queryKey: ['/api/pterodactyl/resources'] });
                toast({
                  title: "Aggiornamento",
                  description: "Statistiche risorse aggiornate",
                });
              }}
            />
          )}

          {/* Bot Commands Examples */}
          <CommandsExample commands={commandExamples} />
        </div>

        {/* Navigation bar for monitoring tools */}
        <div className="px-4 py-2 bg-discord-dark border-t border-gray-800 flex items-center justify-end space-x-4">
          <a 
            href="/resource-monitor" 
            className="text-sm bg-discord-blurple hover:bg-opacity-80 px-3 py-1 rounded text-white flex items-center"
          >
            <i className="fas fa-chart-line mr-2"></i> Monitoraggio Avanzato
          </a>
        </div>

        {/* Status bar */}
        <StatusBar 
          wireguardStatus={typedWireguardStatus.status}
          pterodactylStatus="connected"
          serverIp={"65.108.8.246"}
          usersConnected={wireguardPeers.length}
        />
      </div>

      {/* Members sidebar */}
      <MembersSidebar users={users} />
      
      {/* Modals */}
      <RoleModal 
        isOpen={isRoleModalOpen}
        onClose={() => setIsRoleModalOpen(false)}
        onConfirm={handleRoleConfirm}
      />
      
      <AlertModal 
        isOpen={isAlertModalOpen}
        onClose={() => setIsAlertModalOpen(false)}
        alert={currentAlert}
        onIgnore={handleAlertIgnore}
        onAction={handleAlertAction}
      />
      
      <WireGuardConfigModal
        isOpen={isWgConfigModalOpen}
        onClose={() => setIsWgConfigModalOpen(false)}
        onGenerate={handleWgConfigGenerated}
      />
      
      <MigrationModal
        isOpen={isMigrationModalOpen}
        onClose={() => setIsMigrationModalOpen(false)}
      />

      <WireGuardConfigModal 
        isOpen={isWgConfigModalOpen}
        onClose={() => setIsWgConfigModalOpen(false)}
        onGenerate={handleWgConfigGenerated}
      />
    </div>
  );
};

export default Dashboard;
