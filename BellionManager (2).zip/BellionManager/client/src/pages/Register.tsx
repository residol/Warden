import React from 'react';
import { RegisterForm } from '../components/auth/RegisterForm';
import { useLocation } from 'wouter';
import { useQueryClient } from '@tanstack/react-query';

export default function RegisterPage() {
  const [_, setLocation] = useLocation();
  const queryClient = useQueryClient();

  // Ottieni il token di invito dalla query string, se presente
  const params = new URLSearchParams(window.location.search);
  const inviteToken = params.get('token') || undefined;

  const handleRegisterSuccess = () => {
    // Invalida la cache per ricaricare i dati utente
    queryClient.invalidateQueries({ queryKey: ['/api/auth/profile'] });
    
    // Reindirizza alla dashboard dopo la registrazione
    setLocation('/dashboard');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <h1 className="text-3xl font-extrabold text-gray-900">
            {inviteToken ? 'Completa la registrazione' : 'Registrati'}
          </h1>
          <p className="mt-2 text-sm text-gray-600">
            {inviteToken 
              ? 'Sei stato invitato a unirti al nostro sistema' 
              : 'Crea un nuovo account per accedere al pannello di controllo'}
          </p>
        </div>
        
        <RegisterForm 
          inviteToken={inviteToken} 
          onSuccess={handleRegisterSuccess} 
        />
        
        <div className="text-center mt-4">
          <p className="text-sm text-gray-500">
            Hai già un account? <a href="/login" className="text-blue-500 hover:underline">Accedi</a>
          </p>
        </div>
      </div>
    </div>
  );
}