import React from 'react';
import { LoginForm } from '../components/auth/LoginForm';
import { useLocation } from 'wouter';

export default function LoginPage() {
  const [_, setLocation] = useLocation();

  const handleLoginSuccess = () => {
    // Reindirizza alla dashboard dopo il login
    setLocation('/dashboard');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <h1 className="text-3xl font-extrabold text-gray-900">
            Pannello di controllo
          </h1>
          <p className="mt-2 text-sm text-gray-600">
            Accedi per gestire server, rete e impostazioni
          </p>
        </div>
        
        <LoginForm onSuccess={handleLoginSuccess} />
        
        <div className="text-center mt-4">
          <p className="text-sm text-gray-500">
            Non hai un account? <a href="/register" className="text-blue-500 hover:underline">Registrati</a>
          </p>
        </div>
      </div>
    </div>
  );
}