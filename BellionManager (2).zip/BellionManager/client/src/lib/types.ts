/**
 * Interfacce condivise per il sistema WireGuard
 */

export interface WireguardPeerStatus {
  publicKey: string;
  allowedIps: string;
  latestHandshake: string;
  transferRx?: number;
  transferTx?: number;
  persistentKeepalive?: string;
  name?: string;
  totalConnections?: number;
  lastConnectionDuration?: number;
}

export interface WireguardStatus {
  interface: string;
  listenPort: number;
  publicKey: string;
  peers: WireguardPeerStatus[];
  status: 'online' | 'offline' | 'degraded';
  totalTraffic: string;
  onlinePeers: number;
  totalPeers: number;
}

export interface FirewallRule {
  id: number;
  peerId: number;
  type: 'limit' | 'block' | 'allow';
  direction: 'in' | 'out' | 'both';
  protocol?: 'tcp' | 'udp' | 'icmp' | 'all';
  port?: number;
  portRange?: string;
  rateLimit?: number;
  description?: string;
  enabled: boolean;
  createdAt: string;
}